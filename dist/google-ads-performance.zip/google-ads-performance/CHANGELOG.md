# Changelog google-ads-performance

## 23/11/2026
- 🟡 Sez. 5: dal 04/02/2026 Google Ads raccoglie in automatico più eventi dal sito, richieste di rete in più verso domini Google (release notes GTM lette il 23/11/2026, via Mother).

## 22/11/2026
- 🟡 Sez. 13: sapere via Mother (22/11): dove si fa la verifica dell'inserzionista (/aw/policy/account), le due attività e i documenti, esito che arriva dopo.

## 21/11/2026
- 🔴 Sez. 4: le guide 15081888 e 11347292 (rilette il 21/11/2026) danno per completata la migrazione all'impostazione unica delle conversioni avanzate web e lead, con tag, Data Manager e API accettati insieme; controllo sul pannello e formato Data Manager obbligatorio per i lead.

## 20/11/2026
- 🟡 Sez. 2: come allineare CPA e ROAS target al rendimento reale (mese precedente escluso il ritardo delle conversioni), pagina 17061251 riletta il 20/11/2026.

## 19/11/2026
- 🔴 Sez. 6: budget minimo di piattaforma per Demand Gen 5 USD al giorno, sotto non si pubblica né si aggiorna; annunci limitati per Implied Interactivity; simulatore di scala tCPA (pagina 13695777 riletta il 19/11/2026).
- 🟡 Sez. 7 e 13: scheda Recommended Investment Strategy nei Consigli (16604266); scheda Invalid Traffic Overview e rapporto Invalid Activity Credit (blog del 12/11/2026, pagina 16826168); verifica dell'inserzionista richiesta per targeting multi-paese, query di marchio e verticali a rischio (15588490).

## 18/11/2026
- 🔴 Sez. 12: sapere via Mother #28 (18/11): caricando video in PMax il pannello propone come destinazione il canale YouTube di un altro cliente; si sceglie il canale di archiviazione e si controlla su YouTube.

## 17/11/2026
- 🔴 Sez. 1, 2, 4, 5, 6, 7, 9, 10, 12, 13 e 14: 28 saperi verificati in pratica dalle chat di progetto (via Mother #28): prezzo di riserva, Quota impressioni target, apertura account e inviti, Reach Planner, Keyword Planner a fasce, Rimuovi e campagne finite, Demand Gen (inventario, report, conversioni gonfiate), ricorso Limited ad serving, asset immagine e snippet, valore obbligatorio delle conversioni, ID ed etichetta da trampoline, anteprima annunci, PMax (sitelink, logo, video, canali), amministratori e MCC, obiettivi personalizzati.
- 🔴 Sez. 4: rettifiche delle conversioni con ID ordine (rettifica e ritiro), lette dalle offerte solo nei 7 giorni dopo la registrazione, nei report fino a 54; ritiro irreversibile salvo ricarico con timestamp spostato. 🟡 Sez. 2: Search Journey Awareness integrata nello Smart Bidding (Search e inventario Search di PMax).

## 14/11/2026
- 🟡 Sez. 13: dettagli della pagina ufficiale sulle passkey (dispositivo principale, browser supportati, 1-2 giorni per l'aggancio, stato degli utenti). Data in cima al 14/11/2026.

## 12/11/2026
- 🔴 Sez. 4: la pagina GTM 12131703 dichiara completata per tutti la migrazione all'impostazione unica dei dati forniti dall'utente (tag, Data Manager, API insieme); resta la regola di Cristiano di leggere il pannello. 🟡 Sez. 0: aggiornamenti delle norme dell'11/11/2026 (pubblicità personalizzata e categorie vietate, impersonazione di personaggi pubblici con l'IA anche se dichiarata, telemedicina NABP in tre paesi, norma Sicurezza dei minori da gennaio 2027). 🟡 Sez. 4: colonne da aggiungere quando le ricerche di brand mostrano zero. 🟡 Sez. 8: avviso di almeno 7 giorni prima della sospensione per i marchi (pagina italiana). 🟡 Sez. 12: 2-3 settimane prima di leggere Efficacia dell'annuncio e sostituire asset. Data in cima al 12/11/2026.

## 11/11/2026
- 🔴 Sez. 2: esplorazione Smart Bidding (tolleranza ROAS, estesa a tutte le PMax senza feed, beta su Shopping e PMax con feed) e modalità promozione; obiettivi del ciclo di vita del cliente (valore nuovo cliente, alto valore, solo nuovi clienti anche con CPA target, re-engagement solo PMax, membri fedeltà, modalità nuovi potenziali clienti; moltiplicatori percentuali della stampa [DA VERIFICARE]). 🔴 Sez. 4: risposte qualificanti nei moduli per i lead (solo Search, azione «Lead form - Response qualified», domanda obbligatoria). 🟡 Sez. 1: inserzioni in AI Mode in 10 nuovi paesi dal 28/10, Italia esclusa, multiturn negli USA. 🟡 Sez. 4: Attributed branded searches, pagina Accelerate. Segnali dalle News-Parade di ADworld Experience (regola B4-bis), fonti solo ufficiali. Data in cima all'11/11/2026.

## 09/11/2026
- 🟡 Sez. 14: caso di prima mano sul ricorso per la Pubblicazione di annunci con limitazioni: ricevuta automatica (niente account nuovi prima della risposta), esito positivo in circa 16 ore, mail di esito a cui rispondere se negativo. Data in cima al 09/11/2026.

## 08/11/2026
- 🔴 Sez. 14 nuova (richiesta di Cristiano via chat [Blog] Ads #24): stato «Pubblicazione di annunci con limitazioni» (Limited ad serving): cos'è e come si vede (notifica nell'account, nessuna disapprovazione), chi è inserzionista qualificato, lo scenario «relazioni con i brand poco chiare o annunci generici», come scrivere annunci di servizi su piattaforme altrui (dominio fissato in posizione 1, rapporto dichiarato, brand proprio in chiaro), modulo di ricorso con campi e tempi (5 giorni lavorativi), opzioni DSA per l'UE, estensione a Demand Gen e Performance Max (agosto 2026, entro il 2028), cosa non fare. Descrizione e Fonti aggiornate; data in cima all'08/11/2026.

## 07/11/2026
- 🟡 Sez. 0: pagina API sulla dichiarazione politica UE aggiornata al 30/10/2026: dalla v26 il campo è facoltativo solo per le campagne che non puntano l'UE in positivo; per le campagne italiane nulla cambia. Data in cima al 07/11/2026.

## 05/11/2026
- 🔴 Sez. 12: etichette per i contenuti creati o modificati con l'IA (pagina 17140115, rimandi aggiunti il 04/11 alle norme sugli asset immagine, alle immagini PMax e ai video): dichiarazione nel Centro annunci e sovrimpressione visibile per le campagne con target UE, colonna «AI label» nella Libreria asset, etichette automatiche non rimovibili.
## 27/10/2026
- 🔴 Sez. 13: annuncio di servizio Google Ads del 26/10/2026: dall'11/11/2026 passkey obbligatoria per le azioni sensibili (aggiungere utenti, collegare account; l'accesso non cambia), rollout per account con notifica; pagine ufficiali 16917887, 16968810 e 17423445: abbinamento in 1-2 giorni, 24-48 ore di blocco, piena attività dopo 7 giorni, passkey Android automatiche non valide, email gratuite bloccate in un pilota. Fonti aggiunte.

## 26/10/2026
- 🔴 Sez. 5, 9 e 12: regola di Cristiano del 25/10/2026 (`feedback_piattaforme_e_campagne.md`, via manutenzione #17): ogni inserzione nasce con parametri URL dello standard del progetto, URL di destinazione sulla pagina giusta, invito all'azione dove il formato lo prevede e, dopo la pubblicazione, rilettura dei parametri e clic di prova; su Google tagging automatico o suffisso già in uso, prova senza clic a pagamento [DA VERIFICARE]; i brief senza i quattro punti vengono rifiutati dal controllo automatico. Rimandi in sez. 9 e 12.

## 21/10/2026
- 🔴 Sez. 13 nuova, su richiesta di Cristiano (chat Shipminds, 21/10/2026): aprire un account Google Ads intestato a un cliente da zero: fuso, valuta e paese per sempre (9842104), creazione dall'MCC o senza campagna (6139186, 6366720), collegamento a un altro gestore (7459601), profilo pagamenti del cliente e livelli di accesso per chi mette la carta (2375375, 9978556, 6372672), verifica dell'inserzionista con 30+30 giorni e pausa (9703665, 15588490, 9872152, 9872280), sospensioni e account correlati (2375414).
- 🟡 Sez. 6: «Demand Gen drop» di ottobre (blog Google 13/10/2026): metrica Data Strength Uplift in arrivo, Data Manager su DV360 e GA, conversioni avanzate presto su DV360 e GA; il +20 % con Tag Gateway è analisi interna Google.
## 20/10/2026
- 🟡 Sez. 0 e 7: mail di servizio Google Ads del 19/10/2026 sulla dichiarazione annunci politici UE (notifica standard): campagne dichiarate «contiene» non pubblicate nell'UE dal 22/09/2025; dal 01/04/2026 un account con campagne non dichiarate vede fallire via API e script tutte le modifiche alle campagne (pagina Ads API agg. 14/10/2026, ppc.land 26/02/2026); si dichiara a livello di account sugli account ereditati.
## 17/10/2026
- 🟡 Sez. 4: mail di servizio Google Ads del 16/10/2026: dal 16/11/2026 Data Manager tratta per default dati clienti cifrati in un Trusted Execution Environment, hash SHA-256 ancora accettati, nessuna azione; pagina ufficiale non trovata, data [DA VERIFICARE].
## 15/10/2026
- 🔴 Sez. 12 e sez. 0: priorità dei canali e allocazione del budget (blog.google, 14/10/2026) per Search, Shopping, PMax e Demand Gen: canali Alta o Bassa priorità, percentuale massima di budget giornaliero sui bassi, «Google channels» in PMax e Demand Gen; da febbraio 2027 rimossa la ripartizione attuale nelle Search con Rete Display accesa (Display a Bassa priorità con 50 % per tenerla). Sez. 0: metrica Data Strength Uplift annunciata il 13/10/2026 nel Demand Gen Drop, non ancora vista su un account.
## 14/10/2026
- 🔴 Sez. 3: blocco «Metodo di test e lettura dei dati» dal corso «La cultura del dato» di Cristiano (lezioni 3b, 5 e 6 lette su Drive) e dalla sua decisione del 14/10/2026 su ScegliNatura («si testa finché non si trova l'assetto migliore»), su richiesta della chat [ScegliNatura] Ecommerce #29: quattro criteri di stop fissati prima, niente peeking, lettura solo alla data e sopra il minimo di osservazioni, campione contro differenza, «non significativo» non è «uguale», significatività statistica e pratica, clic non sono vendite, correlazione e causalità, sei domande davanti a un report, campione rappresentativo.

## 07/10/2026
- 🔴 Sez. 10: regola di Cristiano del 07/10/2026 (chat [Blog] Ads #23, globale, `feedback_gads_efficacia_eccellente.md` letto su Drive): ogni annuncio adattabile si porta a efficacia «Eccellente», Buona non basta; si legge sul pannello al montaggio e si lavora sulle quattro leve; posizioni fissate solo con più alternative e controllando che resti Eccellente; se una scelta di Cristiano lo impedisce glielo si dice col punteggio. Il dato di Google (best practice a Buona, efficacia fuori dall'asta) resta come dato.
- 🔴 Sez. 9, 10 e 11 (nuove; Performance Max diventa la 12): reintegrate dalla copia locale di Cristiano del 05/09/2026 (`Blog/Ads/skills/google-ads-performance.md`, letta su Drive) su richiesta della chat [Blog] Ads #23 del 07/10/2026: checklist di montaggio di una Search oltre il wizard (data di fine, secondo RSA con +6,6 % e +3,7 %, esclusioni, DSA, ACA, programmazione, IP, osservazione), asset immagine su Search, trappole del pannello del 13/08, marchi nel testo (norme 6118, nessuna regola sul caso «Google Ads» nei titoli, [DA VERIFICARE] Brand Resource Center); efficacia dell'annuncio (non entra nell'asta, due RSA Buoni, quattro leve, pinning); nome e logo dell'attività (globo di default, spesa Search 28 giorni e verifica, 25 caratteri, specifiche del logo, priorità, tempi). Fonti rilette il 07/10/2026: 9921843, 6167118, 7684791, 6167122, 12497613, 12499303, 9566341, 10347108, 6118. Novità rispetto al 13/08: requisiti di account per gli asset immagine (60 giorni, spesa Search 30 giorni) e logo reso a 28x28 px.
- 🟡 Sez. 1: AI Max, da 15910187 e blog.google (agg. 11/06/2026): ACA e generica di campagna convertite da settembre 2026, Search standard non toccate; text customization ed espansione URL partono accese; «AI Max won't be effective if campaigns are limited by budget».
## 05/10/2026
- 🟡 Sez. 0: aggiunta la pagina ufficiale della modifica sul nome dell'attività ([18287059](https://support.google.com/adspolicy/answer/18287059?hl=en), pubblicata il 01/10/2026): conferma condizioni ed esclusioni, dice solo «ottobre 2026»; il giorno resta [DA VERIFICARE] (19/10 nell'email di servizio, 16/10 per seroundtable). Non in skill: dal 05/10/2026 la policy «Government documents and services» ammette solo fornitori autorizzati da un sito governativo ([17260489](https://support.google.com/adspolicy/answer/17260489?hl=en)), fuori perimetro dei clienti.
## 03/10/2026
- 🔴 Sez. 0, 4 e 7: correzione dalla chat di manutenzione (pannello verificato il 02/10/2026): le conversioni avanzate web e lead non sono ancora una funzione unica su un account reale, due righe con due metodi in Impostazioni conversioni; la guida 16884284 parla ancora al futuro. Aggiunto che lo stato «attiva» e la diagnostica compaiono solo dopo il primo invio con dati utente.
## 02/10/2026
- 🔴 Sez. 0 e 7: promozioni automatiche dal 12/10/2026 su Search e PMax con asset posizione (email di servizio Google del 01/10, pagine 18057626 e 7175034): attivazione automatica, percorso per spegnerle, controllo in igiene.
- 🔴 Sez. 0: norme sul nome dell'attività dal 19/10/2026 (email di servizio del 01/10): nome diverso dal dominio ammesso con relazione verificata, esclusi rivenditori e affiliati; pagina 14847993 non ancora aggiornata.
- 🟡 Sez. 0: Customer Match a otto colonne con IP e timestamp (7659867). Sez. 6: dettagli della migrazione Display in Demand Gen (nome #2, 100 per lotto, 42 giorni, 1-2 giorni di apprendimento). Data di verifica al 02/10.
## 01/10/2026
- 🟡 Sez. 0: norme pubblicità personalizzata dal 30/10/2026: alcolici personalizzabili su inventario YouTube (esclusi quattro paesi, salute e minori vietati). Pagina 17061251 (target dal 17/08) riletta: invariata. Data di verifica al 01/10.
## 30/09/2026 (sera)
- 🔴 Sez. 9: regola di Cristiano del 30/09/2026 (ScegliNatura, resa globale, via chat di manutenzione): nelle grafiche di prodotti con claim regolati solo i testi già presenti sulla scheda prodotto del sito, nessuna aggiunta; controllo a macchina parola per parola.
## 30/09/2026
- 🔴 Sez. 4: regola di Cristiano dal collaudo del 29/09/2026 sul Blog (via chat di manutenzione del 30/09): un invio di prova senza gclid non entra in «Conversioni» né in «Tutte le conv.»; il tag si verifica dal riquadro «Ultimo ping evento» in Obiettivi > Conversioni; due errori da evitare (tag dato per rotto con colonne a zero, invii di prova sottratti).
- 🔴 Sez. 9: nuova voce sulle immagini che passano la revisione, dalle pagine ufficiali rilette il 30/09/2026: PMax con almeno un'immagine senza overlay per proporzione e contenuto nell'80% centrale (14530211); niente testo o loghi sovrapposti sugli asset immagine di Google.com e YouTube Search (10347108); prezzo in grafica uguale alla pagina (Misrepresentation 6020955); claim di cura vietati (15595718); niente testo, loghi o watermark sulle immagini prodotto in Merchant Center (6324350); nessuna soglia del 20% di testo. Due dettagli della manutenzione non riletti marcati [DA VERIFICARE]. Data di verifica al 30/09.
## 29/09/2026
- 🔴 Sez. 3 e 5: regole di Cristiano dalle chat Cowork: campagne nuove come test con ipotesi, budget, durata e soglie fissate prima, modello approvato poi duplicato, schema unico dei nomi, perimetro filtrato alla fonte (`feedback_piattaforme_e_campagne.md`, globale dal 28/09/2026); CSV dei pannelli in formato italiano dichiarato nel lettore, righe Totale tagliate, controllo di una riga nota prima di comunicare un numero (`feedback_csv_numeri_italiani.md`, 13/08/2026). Fonti web e data di verifica invariate.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 5: "Investment strategy" nei Consigli, modalità Holistic e Growth, previsione a 7 giorni, regola di non applicare in blocco (16604266, pagina aggiornata al 24/09/2026); nota sull'avviso di calo del valore di conversione (seroundtable 24/09, non ufficiale).
## 24/09/2026
- Data di verifica in cima a 24 settembre 2026; sez. 0 punto 6 con i cambi del 23/09/2026.
- Sez. 1: blocco "Dal 23/09/2026, come si legge e si testa AI Max": vista "Termini di ricerca e combinazioni di annunci", righe di totale AI Max nel rapporto keyword, filtro AI Max che sottostima (16470459); AI Brief in beta chiusa anche in italiano (blog.google 23/09/2026); esperimenti AI Max contro DSA, limiti 100% DSA e campagne miste (2471185).
- Sez. 7: punto 12 su Ask Advisor (beta, non MCC) che su approvazione mette in pausa campagne e cambia budget (16574983, ppcnewsfeed 22/09/2026), con la regola di leggere la cronologia modifiche su un account ereditato.
## 23/09/2026
- Sez. 5: aggiunta la regola di Cristiano dalla chat Cowork del 19/09/2026 (Sceglinatura, `feedback_numeri_dal_pannello_non_da_ga4.md`): i numeri della campagna si leggono in Google Ads, GA4 solo per tendenze; niente tabelle miste.
- Sez. 8: aggiunta la voce sul classificare termini di ricerca dal nome (`feedback_verifica_catalogo_prima_di_classificare.md`, 19/09/2026): si verifica sul sito del cliente o si chiede, con il caso lenivox/ansiwit. Data di verifica delle fonti invariata: non sono fonti web.

## 20/09/2026

- Aggiornata la data di verifica in cima a 20 settembre 2026 e aggiunto il blocco "Cosa è cambiato" con date (sez. 0, regola 3 dell'autore).
- Aggiunto in sez. 0 il punto 5: la pagina annunci ufficiale 9048695 è ferma al 20/05/2026, i cambi si intercettano dagli avvisi in cima alle pagine Help e dal Developer Blog.
- Sez. 1: separato il numero Google (almeno 30 conversioni, 50 per ROAS target; 7065882, 6268632) dalle soglie 30-50 e 50-100 conversioni/mese, ora etichettate "regola empirica, non numero Google" con attribuzione ai blog (stackmatix, infrontmarketing).
- Sez. 1: aggiunta la fascia 10-30 conversioni/mese come scelta caso per caso, senza regola inventata.
- Sez. 1: aggiunta la regola AI Max: creazione della generica di campagna bloccata dal 03/08/2026, conversione automatica 1–30/09/2026, controlli post-conversione (search term matching, text customization, espansione URL finale, rapporto termini separato keyword/AI Max), DSA da febbraio 2027 (13389795, blog.google, Developer Blog 12/08/2026, ppc.land).
- Sez. 1: aggiunto il test AI Mode con keyword esatte e a frase confermato il 04/09/2026 (ppc.land; nessuna pagina Help trovata).
- Sez. 1: precisato che l'elenco esclusioni a livello di account ha limite di 1.000 parole chiave, vale per Search, PMax, App, Shopping, Smart, Local e non cita Demand Gen (11396330).
- Sez. 2: "due-quattro settimane senza target" etichettato come regola empirica (groas 23/04/2026), affiancato dal numero Google sul volume.
- Sez. 2: aggiunto il cambio del 17/08/2026 (rollout 27/08): CPA/ROAS/CPC target consegnano al target sulle campagne limitate dal budget; Bid Target Adjustment Tool dal 06/07/2026; elenco campagne interessate ed escluse (17061251, 17125145).
- Sez. 3: sostituita la frase vaga "pratica di dieci anni fa" con il legame alla soglia delle 30 conversioni; aggiunta la rimozione del targeting per lingua da Search e dalla parte Search di PMax da fine settembre 2026 (1722078, Developer Blog 13/08/2026).
- Sez. 4: aggiunta la conversione "Ricerche di brand" (primaria solo di nome, reporting, finestra 7 giorni, brand mapping) (16212033).
- Sez. 4: corrette le conversioni avanzate: web e lead unificate da giugno 2026 con unico interruttore, caricamenti offline e lead solo via Data Manager API dal 15/06/2026 (16884284); aggiunti i limiti 90/63 giorni (15081888) e la regola dei 7 giorni per l'attribuzione basata sui dati, segnalata come fonte terza non verificata (ppc.land 22/08/2026).
- Sez. 4: modello di attribuzione riscritto come "basato sui dati o ultimo clic", gli altri modelli non più supportati; data della rimozione dichiarata non verificata (6259715).
- Sez. 5: corretta la frase su UTM e gclid: il tagging automatico ha la priorità sul manuale, gli UTM non rompono l'importazione delle conversioni; il consiglio di non stratificare UTM resta con la motivazione giusta (3095550). Aggiunto il percorso completo dell'auto-tagging.
- Sez. 5: aggiunta la fonte per l'applicazione automatica dei consigli (10279006) e il controllo sugli esperimenti, che da aprile 2026 applicano i risultati in automatico di default (ppcnewsfeed; Search Engine Land 473266 in 403).
- Sez. 6: reti Demand Gen corrette: YouTube, Discover, Gmail, Maps, Rete Display, video partner (13695777); aggiunta la migrazione delle campagne Display standalone dentro Demand Gen con Rete Display non deselezionabile (17051545, blog.google).
- Sez. 6: aggiunta la fonte ufficiale del +35% conversioni su Shorts (9128498); aggiunto il 4:5 fra i rapporti video ammessi.
- Sez. 6: aggiunte le pagine specifiche separate per immagini (17140672) e video (17141078: 1-5 video per annuncio, minimo 5 s, sotto 10 s non serve su In-stream, consigliati oltre 15 s); "20 immagini per annuncio" ora citato da 15701616.
- Sez. 6: aree di sicurezza riscritte con le zone Google per Shorts (10% alto, 25% basso, 10% destra; 9128498, business.google.com); il vecchio 90%/80% dichiarato regola di blog per il 16:9.
- Sez. 6: budget Demand Gen: aggiunto il minimo 5 USD/giorno via API dal 01/04/2026 e la raccomandazione di almeno 10× il CPA target (prima 15-20×, abbassato a settembre 2026) (13695777, Developer Blog 27/02/2026, ppc.land, twooctobers 01/09/2026); aggiunta la fonte per i 60 secondi nel feed Shorts (16041697).
- Sez. 6: aggiunti i lookalike come suggerimenti e non vincoli da marzo 2026 (13541369).
- Sez. 7: aggiunto il controllo sugli esperimenti (punto 1), la nota su "Ricerche di brand" (punto 2), la voce unica delle conversioni avanzate e il canale Data Manager (punto 3), il percorso e la fonte del contatto per la protezione dei dati (punto 6, 7687725).
- Sez. 7: soglia remarketing esplicitata a 100 utenti attivi negli ultimi 30 giorni su tutte le reti da dicembre 2025 (2472738); aggiunta l'etichettatura automatica del tipo cliente su Customer Match dal 18/08/2026 (12080169, digitalapplied).
- Sez. 7: aggiunti i punti 10 (ricontrollo target impostati prima del 17/08/2026) e 11 (impostazione video PMax).
- Sez. 8: aggiunti "lasciare un CPA target largo dopo il 17/08/2026" e la rilettura del rapporto termini di ricerca dopo la conversione ad AI Max.
- Nuova sez. 9 Performance Max: gruppi di asset, esclusioni di campagna e di account (11396330), rapporto per canale, esclusione clienti esistenti, ridimensionamento video con IA generativa con opt-out entro il 04/09/2026 (Search Engine Land 485252), rimandi a lingua e target. Nessuna soglia numerica aggiunta.
- Fonti riscritte: URL confermate divise fra ufficiali e terze parti; corrette le etichette fuorvianti (10195720 non contiene soglie né regole sulle esclusioni; 13676244 ha i numeri dentro immagini; stackmatix aggiornato il 13/09/2026, dopo la verifica dell'11/08); aggiunte tutte le pagine ufficiali nuove; elencate le pagine non leggibili.
- Non verificato al 20/09/2026: corpo dei post del Google Ads Developer Blog del 27/02, 12/08 e 13/08/2026 (solo titolo e data); Search Engine Land 473266 e 433352 (403); data esatta della rimozione dei modelli di attribuzione (fonte con le date in 403); pagina ufficiale sui rapporti di attribuzione per la regola dei 7 giorni sulle conversioni offline; pagina Help sui gruppi di asset PMax; data della migrazione automatica finale Display → Demand Gen (gennaio 2027 solo da fonti terze); nessuna pagina Help per il test AI Mode con esatta e frase.
