# Changelog consent-mode-privacy

## 22/11/2026
- 🟡 Sez. 7: sapere via Mother (22/11): Complianz blocca Jetpack Stats fino al consenso, calo delle visite Jetpack da leggere con la data di attivazione della CMP.

## 17/11/2026
- 🔴 Sez. 7, 11 e 12: 14 saperi verificati in pratica dalle chat di progetto (via Mother #28): CMP sotto GTM e default negato come rete di sicurezza, Complianz gratuito senza Consent Mode e con il modello di Simo Ahava, prova dei tre stati, regole GTM per lingua, crollo degli Utenti attivi da CMP, script iniettato dal container, limiti del Complianz gratuito, Iubenda senza googleConsentMode, prove con Chrome headless, banner su iPhone, Modalità provvisoria, Iubenda senza evento di cambio consenso.

## 16/11/2026
- 🟡 Sez. CMP: pagina del programma partner riletta, tre livelli (Gold, Silver, Bronze), livelli dei CMP citati confermati, bollino App-ready.

## 20/09/2026
- Prima stesura da fonti ufficiali: developers.google.com/tag-platform (concetti consent mode, guida implementazione, debug Tag Assistant); Google Ads Help 10000067, 10548233, 14218557, 14522438, 13695607, 14009343, 16142339; Analytics Help 11161109, 14275483, 17016975; Tag Manager Help 10718549, 14546074, 14546767; EU user consent policy; Google Account Help 14202510 (DMA); cmppartnerprogram.withgoogle.com; Garante docweb 9677876 (Linee guida 10/06/2021), 9679893, 10118222, 10162286, 9782874, tema Cookie; EDPB pagina Linee guida 2/2023 e parere congiunto EDPB-EDPS 2/2026; blog Microsoft Advertising 31/03/2025 e 19/02/2026; Meta Business Tools Terms, doc pixel GDPR, doc data processing options (LDU).
- Non verificato: Google Ads Help 13554116, 13695824, 14319609 (404); Analytics Help 12334045 (solo glossario); nessuna pagina Help pubblica sull'uso degli IP per annunci in SEE dal 03/08/2026 (fonti terze: ppc.land, iubenda blog); data esatta del passaggio di `ad_personalization` e degli IP cifrati a Google Ads ("later this year"); pagina Help Microsoft su UET consent mode non leggibile, sintassi `uetq.push('consent', ...)` da fonti terze; support.cookiebot.com 403, mappatura categorie Cookiebot da documentazione terza; PDF EDPB Linee guida 2/2023 non letto; Meta business help 348535683460989 e 1076458978496976 non leggibili; lettura dei valori `gcs` (G100/G111) da documentazione terza; nessun provvedimento cookie del Garante trovato fra giugno e settembre 2026.
