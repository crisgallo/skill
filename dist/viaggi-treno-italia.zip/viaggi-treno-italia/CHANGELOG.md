# Changelog viaggi-treno-italia

## 14/11/2026
- 🟡 Sez. 9: correzione della nota del 12/11 sui treni garantiti (le condizioni dell'elenco speciale sono cumulative); avviso Adriabus per lo sciopero generale del 20/11/2026 con le fasce. Data in cima al 14/11/2026.

## 12/11/2026
- 🟡 Sez. 9: pagina Trenitalia dei treni garantiti riorganizzata (due elenchi per la lunga percorrenza secondo il tipo di sciopero, categoria indicata nel dettaglio del treno, fasce regionali confermate). Data in cima al 12/11/2026.

## 30/10/2026
- 🟡 Sez. 3 e 5: pagine CartaFRECCIA e tariffe Italo rilette il 30/10/2026: Platino Infinito (+100%, 5 upgrade, non scade), lounge con due ospiti per Platino; Extra Tempo è un'ora su un altro Italo, compreso nella Flex (tolto il [DA VERIFICARE]); Parti Ora 15 € a passeggero solo il giorno della partenza.
## 28/10/2026
- 🟡 Sez. 10: ATM Milano, tetto giornaliero di 7,60 € dalla quarta corsa, penali senza tap out, carte non accettate, linee S escluse; URL della pagina ATM corretto (il vecchio risponde 404).
- 🔴 Prima stesura su richiesta di Cristiano via manutenzione #17 («Sì, falla preparare»), 15 sezioni: come lavora la chat (acquisto solo dopo il sì, calendario, controllo la sera prima, archivio dei biglietti), tariffe Trenitalia Base, Economy e Super Economy con penali e scadenze, CartaFRECCIA (chiude il 31/12/2026, punti fino al 31/03/2027), regionale digitale (convalida automatica, cambi, rimborso 100% fino al giorno prima, indennizzo automatico dal 01/01/2025), Italo (Low Cost, Economy, Flex, opzioni, contratto dal 01/10/2026, Italo Più, Italobus), ritardi e cancellazioni (regolamento UE 2021/782 art. 12, 18, 19, 20 e regole dei due vettori, coincidenze con biglietto unico o separato), fattura elettronica dei biglietti (finestre fino alle 24 del giorno dell'acquisto), corriere extraurbane con Adriabus come esempio (PDF per periodo, niente biglietti a bordo, timer di attivazione), scioperi (fasce garantite, treni garantiti, MIT e CGSSE, preavviso), metro e taxi (Tap&Go Roma, tap in e out ATM, tariffe fisse ADR da Fiumicino), pianificazione porta a porta con margini, spese di viaggio per la partita IVA (circolare 15/E/2025, riaddebito analitico), trappole, meccanica da verificare, cosa non fare mai. Fonti lette il 28/10/2026; marcati [DA VERIFICARE] i punti non letti (condizioni regionali Trenitalia, legge 146/1990, calendari scioperi, ATAC, taxi Milano, Italobus).
