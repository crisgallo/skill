# Changelog linkedin-ads

## 11/11/2026
- 🟡 Sez. 15: CTV Ads acquistabili anche via Display & Video 360 dal 22/10/2026 (pressroom), disponibilità per account italiani [DA VERIFICARE]. Segnale dalle News-Parade di ADworld Experience; fonti aggiunte; data in cima all'11/11/2026.

## 06/11/2026
- 🟡 Sez. 7: pagina a426057 aggiornata il 05/11: effetto del pulsante Not Interested, CTA persistente in fondo allo schermo (graduale, non su iOS).
## 04/11/2026
- 🟡 Sez. 7: pagina a421723 (Sponsored Messaging) aggiornata il 03/11: lingua inglese solo su profili in inglese, Draft with AI solo in inglese, obiettivi per formato, Flowchart dei clic.
## 03/11/2026
- 🔴 Sez. 7: pagina a5964111 aggiornata il 02/11/2026: i post dei paesi DMA non sono individuabili né sponsorizzabili come Thought Leader Ads; per i B2B italiani il formato va dato per non disponibile sui post dei membri italiani, criterio esatto [DA VERIFICARE] sul pannello; menu Sponsorship Permissions > Requests and Posts.
## 29/10/2026
- 🟡 Sez. 2: limiti di selezione del targeting dalla pagina a424655 aggiornata il 28/10/2026: 200 per località e nomi azienda, 100 per ogni altro attributo (la skill diceva 200 per le opzioni demografiche), una lingua del profilo per ad set fra 35, pubblici predittivi aggiornati ogni giorno. Minore perché nessuna campagna reale tocca quei tetti.

## 27/10/2026
- 🟡 Sez. 7: pagina Thought Leader Ads aggiornata da LinkedIn il 26/10/2026: ammessi anche testo, documento e Live Event; CTA solo sugli Event ads; permessi richiesti sulla Pagina; nessun tetto alle richieste; 3° grado solo nel Creator Marketplace; metriche memberFollows e clic al profilo.

## 26/10/2026
- 🔴 Sez. 7: regola di Cristiano del 25/10/2026 (`feedback_piattaforme_e_campagne.md`, via manutenzione #17): ogni inserzione nasce con parametri URL dello standard del progetto, destinazione sulla pagina giusta, invito all'azione dove il formato lo prevede e clic di prova dopo la pubblicazione; brief senza i quattro punti rifiutati dal controllo automatico.

## 15/10/2026
- 🟡 Sez. 15: versione 202610 della Marketing API (recent-changes letta il 15/10/2026): `metadata` sulle creatività, filtro `jobFunction` in Company Intelligence, metriche `memberFollows` e `memberProfileClicks`, Boost API; breaking change `surface` (LAN o CTV) sulle liste publisher dalla 202611, abbinamento obbligatorio dal 15/12/2026; sunset 202510 il 15/10/2026 e 202511 il 16/11/2026. Titolo della sezione esteso a ottobre.
## 08/10/2026
- 🟡 Sez. Conversions API: pagina a1718034 (CAPI via GTM) aggiornata il 07/10/2026: un container server Stape per account idoneo senza costi dal setup guidato di Campaign Manager, condizioni di pubblicazione automatica, dati dopo qualche ora, dedup con eventId. Nessuna regola cambiata.
## 23/09/2026
- Sez. 2: aggiunti i Buyer Groups (fino a tre categorie di prodotto) fra i pubblici generati automaticamente (a425184).

## 20/09/2026

- Prima stesura da fonti ufficiali: pagine Help LinkedIn Marketing Solutions (a423690 dimensione pubblico, a424655 e a417950 targeting, a1489764 e a423102 liste, a420433 e a420297 retargeting e retention, a1631056 predittivi, a423698 fine lookalike, a418929 Audience Expansion, a423409 / a425378 / a427359 Audience Network, a1337901 Brand Safety Hub, a421112 / a706289 / a420561 offerte e asta, a422101 / a427572 budget, a424570 obiettivi, a426534 / a424737 / a423663 / a737898 / a426057 specifiche formati, a421723 e a577123 Sponsored Messaging in UE, a1399568 Thought Leader Ads, a423447 / a423364 / a421867 Lead Gen Forms, a1444756 GDPR, a489169 / a423304 Insight Tag e cookie di prima parte, a1680223 / a1718034 CAPI e GTM, a426359 / a426349 / a420533 finestre e attribuzione, a422348 / a426154 / a424171 / a420170 reporting, a423449 Pagina, a468679 revisione, a417903 / a1340134 / a421456 IVA e fatturazione); LinkedIn Advertising Policies; Microsoft Learn (Conversions API 202609, Recent Marketing API Changes 202606–202609); pagina prodotto LAN e best practices budget su business.linkedin.com; Product Updates LMS (fermo al 31/03/2026).
- Correzioni rispetto alla vulgata del brief, documentate in cima alla skill: sforamento giornaliero fino al 100% (non 50%); retention lead 365 giorni (non 90); Sponsored Messaging in UE riaperte da fine 2024 ai soli membri opt-in (non "vietate dal 2022"); lookalike chiuse 29/02/2024 e predittivi con limite 200 per account; Ad Set Quality Score discontinuato 14/08/2024; rinomina campagna/ad set dal 01/10/2025; default finestra 90/90 secondo la pagina Help attuale.
- Novità giugno–settembre 2026 ricavate solo da learn.microsoft.com (API): CTA "Non interessato" automatico, SHA256_IP e hash nome in CAPI, tipi MQL/SQL, finestra 180 giorni, tetto 1.000 segmenti DMP, campi DSA pagante/beneficiario, sunset 202508 (17/08) e 202510 (15/10/2026). Nessun annuncio UI datato trovato nel periodo.
- Non verificato: specifiche complete Document ads (limiti pagine/peso da terzi) ed Event ads; default del modello di attribuzione (ogni ad set / ultimo ad set); campo DSA "pagato da / beneficiario" in Campaign Manager; pagina Help con i minimi 10/100 USD (solo best practices non datata) e minimi in EUR sul pannello; pagina Help sul blocco del cambio obiettivo; esistenza attuale del "target cost"; quota opt-in inbox dei membri italiani per Sponsored Messaging; post del blog LinkedIn Marketing Solutions per giugno–settembre 2026 (nessuno individuato via ricerca).
