# Changelog meta-ads-performance

## 24/11/2026
- 🟡 Sez. 3: attribuzione incrementale come campo `is_incremental_attribution_enabled` del gruppo di inserzioni nella Marketing API (riferimento ufficiale letto il 24/11/2026 via Mother); è un modello, non un test con controllo.

## 18/11/2026
- 🔴 Sez. 6: regola di Cristiano del 18/11/2026 (via Mother) con sei punti verificati sul pannello per mettere in onda un'inserzione: contenuti correlati a «0 di N», prodotti del catalogo, Carosello e Raccolta che si riaccendono da soli, pubblicazione dall'editor della singola inserzione, video verticali solo 9:16, pannello branding che accende il branding automatico, anteprima controllata di persona prima di passare un link al titolare.
- 🔴 Sez. 7 e 10: 2 saperi via Mother #28 (18/11): follow attribuiti nella colonna «Follow di Instagram» e follow netti negli Insights del profilo giusto; dialogo delle colonne senza «Applica» che salva un preset nell'account.

## 17/11/2026
- 🔴 Sez. 1, 2, 5, 6, 7 e 9: 19 saperi verificati in pratica dalle chat di progetto (via Mother #28): feed supplementare da Foglio Google, copie di inserzioni rotte, reel Instagram come inserzione, budget di campagna e data d'inizio, posizionamenti Facebook, etichette del portfolio, targeting Advantage+ con obiettivo Traffico, colonna destra, consegna fra inserzioni dello stesso gruppo, elementi eliminati, modulo di creazione, Libreria inserzioni, spegnimento, SMS della Fatturazione, insiemi di prodotti, modello grafico del catalogo, «Mostra prodotti», verifica dell'azienda, storie programmate.

## 11/11/2026 (sera)
- 🟡 Sez. 5: un pubblico per ogni creatività nello stesso gruppo (creative audience pairing): campo `creative_audience_pairing_persona` documentato nella Ad reference v27.0 (età 18-65, generi); interruttore e vincoli del pannello solo da terzi, [DA VERIFICARE]. Segnale dalle News-Parade di ADworld Experience; fonte aggiunta.

## 11/11/2026
- 🟡 Sez. 1: nuova sottosezione sui post ufficiali Engineering at Meta su GEM (13/10), GenRecs Tokenization (19/10) e Andromeda (28/10/2026): modello centrale unico, token semantici al posto degli ID, recupero a oltre un miliardo di inserzioni al secondo; niente da impostare nel pannello, confermano pubblici larghi e consolidamento; dichiarazioni su targeting e avvio delle creatività citate come stampa (AdExchanger). Segnale dalla newsletter dataMesh (prima applicazione della regola B4-bis). Fonti aggiunte; data in cima all'11/11/2026.

## 10/11/2026
- 🔴 Sez. 5: Marketing API v27.0 del 04/11/2026: «Raggiungi più persone su altri dispositivi mobili» acceso di default sui gruppi nuovi delle campagne Vendite, Product showcase acceso da solo con alta confidenza, Lookalike senza paese o località, moment maker deprecato, OTP sui Lead Ads, Catalog Batch API deprecata; nessuna modifica CAPI. Data in cima al 10/11/2026.

## 08/11/2026
- 🟡 Sez. 0: l'aggiornamento delle Condizioni commerciali, catalogo, inserzioni self-service e IA generativa previsto per il 20/11/2026 è sospeso (pagina ufficiale 2481113349080785, resa l'08/11); restano le condizioni attuali. Data in cima all'08/11/2026.

## 06/11/2026
- 🔴 Sez. 10 nuova (richiesta di Cristiano via chat [Blog] Ads #23): far crescere i follower di un profilo Instagram: nessun obiettivo follower, Traffico con luogo della conversione «Profilo Instagram o Facebook» e obiettivo di prestazioni «Visite al profilo Instagram», colonne «Visite al profilo Instagram» e «Instagram follows» (dal 07/07/2025, alcuni account), Insights a 90 giorni con Follow, Persone che non seguono più e Follower netti, stima dell'incrementale e del costo per follower, Metti in evidenza contro Gestione inserzioni (Apple 30% da iOS), trappole; descrizione aggiornata.
## 30/10/2026
- 🔴 Sez. 6: due regole di Cristiano del 30/10/2026 (chat ScegliNatura, via Ecommerce #34): le immagini 4:5 e 1:1 che escono anche in Storie, Reel o Feed del profilo tengono libera la fascia alta (circa 15%, 270 px su 1800) per l'intestazione «Inserzione»; prima di pubblicare o riaccendere la chat guarda lei stessa l'anteprima di ogni posizionamento in «Modi in cui verrà visualizzata la tua inserzione», e con un elemento coperto non si pubblica. Caso del 29/10/2026: carosello 4:5 con il logo a 110 px dal bordo, coperto in Storie e Reel, inserzioni fermate da Cristiano.
## 28/10/2026
- 🔴 Sez. 6 e 7: verificato sul pannello il 28/10/2026 (manutenzione #17 su richiesta di Cristiano): l'opzione «Aggiornamenti automatici per i video dei prodotti» del catalogo, accesa di default, attacca agli articoli video ricavati anche da inserzioni spente da mesi e le inserzioni a catalogo con «Consenti video del prodotto» li mostrano; pulsante «Rifiuta video», conteggio del filtro che non si aggiorna, cosa fare quando si spengono creatività o si eredita un catalogo; punto 11 nella lettura del pannello.

## 26/10/2026
- 🔴 Sez. 6: regola di Cristiano del 25/10/2026 (`feedback_piattaforme_e_campagne.md`, via manutenzione #17): ogni inserzione nasce con UTM dello standard del progetto, destinazione sulla pagina giusta, pulsante sempre («Usa post esistente» solo se il post ha già link e pulsante) e clic di prova dopo la pubblicazione; caso del 23/10 (due video senza UTM e senza destinazione); brief senza i quattro punti rifiutati dal controllo automatico.

## 22/10/2026
- 🟡 Sez. 9: Developer Policies Meta 10.6.a (annuncio 28/04/2026, in vigore dal 03/02/2027): chi compra per conto del cliente deve rivelare su richiesta spesa Meta separata dalle fee, configurazione e report; 10.5 account pubblicitario separato per ogni inserzionista finale.
## 21/10/2026
- 🔴 Sez. 9 nuova, su richiesta di Cristiano (chat Shipminds, 21/10/2026): aprire da zero un portfolio aziendale e un account pubblicitario intestati a un cliente: limite di portfolio per persona, account pubblicitario con valuta e fuso fissi che non si trasferisce (1 account nei portfolio nuovi, 3 dopo la prima campagna pagata), accesso alla Pagina esistente, Instagram, persone e partner, pagamenti, verifica dell'azienda con documenti italiani, limiti di spesa e blocchi iniziali. Pagine Meta Business non leggibili via fetch: testo Meta da copie di terzi, punti [DA VERIFICARE] sul pannello.
- Non verificato: limite di 2 portfolio per persona, nome dei permessi finanziari, menu in italiano dei Partner, lista ufficiale dei documenti.
## 18/10/2026
- 🟡 Sez. 3: rimando alla funzione del Pixel dal 12/11/2026 (conversioni recuperate sul dispositivo): un salto di conversioni attribuite in quella settimana non è la campagna.
## 16/10/2026
- 🟡 Sez. 0: Brand Building Summit del 15/10/2026 (post ufficiale): Ads Super Burst in GA a fasi (finestra 3-24 ore, Reach Planner, esclusiva di categoria), First Impression Ads in test solo USA, Reels Trending Ads con 15 argomenti ed esclusioni di pubblico entro l'anno, Aggregated View Time in alpha. Prodotti per il brand, nessuna regola cambiata.
## 14/10/2026
- 🔴 Sez. 2: blocco «Metodo di test e lettura dei dati» dal corso «La cultura del dato» di Cristiano (lezioni 3b, 5 e 6 lette su Drive) e dalla sua decisione del 14/10/2026 su ScegliNatura («si testa finché non si trova l'assetto migliore»), su richiesta della chat [ScegliNatura] Ecommerce #29: quattro criteri di stop fissati prima, niente peeking, lettura solo alla data e sopra il minimo di osservazioni, campione contro differenza, «non significativo» non è «uguale», significatività statistica e pratica, clic non sono vendite, correlazione e causalità, sei domande davanti a un report, campione rappresentativo.

## 08/10/2026
- 🟡 Sez. 6: guide immagine Facebook Feed e Instagram Stories rilette l'08/10/2026 (le quattro guide risultavano cambiate): Feed testo principale 50-150 caratteri, titolo 27, tolleranza 3 %; Instagram Stories 125 caratteri, 500 px, 1 %, aree 14/35/6 % invariate.
## 07/10/2026
- 🟡 Blocco «Cosa è cambiato», sez. 5 e 6: annunci di Meta all'Advertising Week New York del 06/10/2026, dal post ufficiale su facebook.com/business/news letto il 07/10/2026: video generato dalle immagini statiche in Advantage+ Creative disponibile a tutti (stato di default non dichiarato, [DA VERIFICARE] sul pannello), Customer Lifecycle Strategy con proposta di esclusione dei clienti esistenti nelle campagne di acquisizione, pubblici descritti a parole in Targeting dettagliato entro fine 2026, generazione video in Ads Creative Studio e video da catalogo in test o beta. Nota che /business/news si legge, a differenza di /business/help.
## 05/10/2026
- 🟡 Sez. 8: limiti di testo e tecnici delle guide immagine rilette il 05/10/2026: Facebook Stories 125/40 caratteri, larghezza minima 500 px, tolleranza 1 %, 8 secondi; Facebook Reels 40/55, 600×600, 3 %.
## 30/09/2026 (sera)
- 🔴 Sez. 6: regola di Cristiano del 30/09/2026 (ScegliNatura, resa globale, via chat di manutenzione): nelle grafiche di prodotti con claim regolati solo i testi già presenti sulla scheda prodotto del sito, nessuna aggiunta; controllo a macchina parola per parola.
## 30/09/2026
- 🔴 Sez. 6: corretto il margine basso delle Stories: le guide ufficiali di Instagram Stories, Facebook Stories e Facebook Reels (lette il 30/09/2026) danno 14% in alto, 35% in basso e 6% per lato per tutte, non «circa 20%» per le Stories. Aggiunte le misure ufficiali: 9:16 a 1440x2560 e Feed 4:5 a 1440x1800, massimo 30 MB; i Reels sconsigliano il testo sulle immagini.
- 🟡 Sez. 6: nuova voce da fonti terze concordi, marcata [DA VERIFICARE] (Transparency Center non letto): fine della regola del 20% di testo, prezzi e sconti in immagine, attributi personali, salute e benessere, immagini di catalogo. Segnalata dalla chat di manutenzione del 30/09/2026. Data di verifica al 30/09.
## 29/09/2026
- 🔴 Sez. 2 e 4: regole di Cristiano dalle chat Cowork (`feedback_piattaforme_e_campagne.md`, globale dal 28/09/2026: campagne nuove come test con ipotesi, budget, durata e soglie fissate prima, modello approvato poi duplicato, schema unico dei nomi, perimetro filtrato alla fonte; `feedback_nessuna_campagna_prima_della_capi.md`, 11/08/2026: nessuna campagna prima della CAPI verificata). Fonti web e data di verifica invariate.
## 23/09/2026
- Sez. 3: aggiunta la regola di Cristiano dalla chat Cowork del 19/09/2026 (Sceglinatura, `feedback_numeri_dal_pannello_non_da_ga4.md`): spesa e risultati da Gestione inserzioni, GA4 solo per tendenze; niente tabelle miste. Data di verifica delle fonti invariata: non è una fonte web.

## 20/09/2026

- Aggiornata la data in cima a "Ultima verifica delle fonti: 20 settembre 2026".
- Sostituito il blocco "Cosa è cambiato il 12/08/2026" con un blocco "Cosa è cambiato" datato per singolo cambio: AEM web ridatato ad annuncio 15/05/2023 e rimozione tab entro metà 2025 (adviso, segwise agg. 03/09/2026), con la nota che la skill se n'era accorta solo il 12/08/2026; conservata l'osservazione sul pannello del 12/08/2026.
- Sez. 0: elencate esplicitamente le tre modifiche del 2026 con date (12/01/2026 finestre, 03/03/2026 clic ed engage-through, 18/05/2026 retention 730 giorni dei pubblici Acquisto); aggiunto al punto 3 che "da quando" è la data del cambio di Meta; aggiunto il punto 6 sulle pagine facebook.com/business/help non leggibili via fetch.
- Sez. 1: etichettati "regola empirica di terzi, non soglia Meta" il 20-25% di budget, la pausa di 7 giorni e gli scaglioni sotto il 20% (withblip, senza data), con accanto la posizione ufficiale "dipende dalla magnitudine" (pagina Modifica significativa 942374239243867, non leggibile via fetch); aggiunta la fonte pigeondigital 01/04/2026 alla soglia dei 50 eventi; aggiunta nota datata sotto "Cosa RESETTA l'apprendimento (verificato 08/2026)", testo originale intatto.
- Sez. 2: etichettati "regola empirica, non soglia Meta" i numeri 1-3 gruppi, 3-4 gruppi sotto 50 $/giorno e 1-2 gruppi a 20 €/giorno, con il criterio 50 eventi ÷ budget; corretta la frase "CBO default dal 2024" con il flusso unificato di febbraio 2026 e i default Advantage+ preselezionati (superscale, admanage, 1clickreport; pagina ufficiale 153514848493595 non leggibile); aggiunte le colonne Diversità creativa (26/08/2026) e Spesa stimata (25/08/2026) (admakeai, adsuploader).
- Sez. 2: aggiunta sottosezione "Location fee (dal 01/07/2026)", Italia 3% fuori dal budget della campagna (tdmp, almcorp, digitalapplied).
- Sez. 2: aggiunta sottosezione "Posizionamenti": rimozione delle esclusioni di posizionamento a livello di gruppo dal 19-21/08/2026 (socialmediatoday 20/08/2026, jonloomer, admakeai, commonthreadco); Messenger Stories rimosso (UI 27/08/2026, API 27/10/2026) e Instagram Explore Feed rimosso in API v26.0 (29/07/2026) (goodmorningco, adsuploader).
- Sez. 3: corretto il default in "7 giorni clic + 1 giorno engage-through + 1 giorno view" (jonloomer, jetfuel 29/03/2026); precisato che la finestra 28 giorni clic resta in reporting; sostituito il "15-30% (7d view)" non ritrovato con il 30-40% sulla finestra 8-28 giorni delle fonti, etichettando il vecchio numero come stima di terzi (dataslayer 19/01/2026); aggiunta la soglia engaged view da 10 a 5 secondi (dataslayer 09/04/2026).
- Sez. 4: dichiarato che il nesso "EMQ sotto 6, la finestra conta poco" è un'inferenza della skill, con la soglia 6/10 confermata da conversios 26/03/2026; ridatata la voce AEM (2023-2025, web) con fonti adviso e segwise; aggiunta la riserva per le campagne app iOS e per gli account non migrati (segwise 03/09/2026); aggiunta la scadenza Marketing API v24.0 del 06/10/2026 e l'estensione delle rimozioni v26.0 al 27/10/2026 (admakeai agosto 2026, kitchn).
- Sez. 5: sostituita la soglia unica "circa 1000 persone" con minimo tecnico 100 per Paese per il lookalike e minimo pratico ~1000 per la consegna (jonloomer, adnabu, tribeupacademy; pagina ufficiale 1523083297982009 non leggibile); aggiunta l'eccezione retention 730 giorni per i pubblici Acquisto dal 18/05/2026 con aggiornamento automatico degli esistenti (rep Meta via X, davidtamachi 06/06/2026).
- Sez. 5, trappole del pannello: aggiunti i pubblici di sola esclusione del 10/08/2026 (socialmediatoday, jonloomer, commonthreadco), le etichette sui pubblici del 16/07/2026 con lookalike e salvati non etichettabili (admakeai agosto 2026) e il paywall Meta One del 15/09/2026 (adsuploader).
- Sez. 6: riscritto "35% in basso" come "fino al 35%" (caso peggiore Reels, Stories circa 20%) e aggiunta la risoluzione raccomandata 1440x2560 con 1080x1920 come minimo (billo 16/06/2026, adnabu, superscale); aggiunto 1440x1800 per il 4:5; aggiunta la riscrittura automatica del testo in immagine di Advantage+ Creative dal 27-28/07/2026 (commonthreadco, admakeai agosto 2026).
- Sez. 7: aggiunti al punto 5 la retention dei pubblici Acquisto, e i punti 8 (interruttori Advantage+ e posizionamenti), 9 (suddivisioni dispositivo/ora/frequenza opt-in dal 06/08/2026, zeri silenziosi; goodmorningco, admakeai) e 10 (permessi del server MCP ufficiale, 16/07/2026 e 11/08/2026; admakeai settembre 2026).
- Sez. 8: etichettata come osservazione su un caso la frase sul pubblico freddo B2B; aggiunto "non dare per scontata un'esclusione di posizionamento montata mesi fa".
- Fonti: riscritta la sezione per gruppo tematico; rietichettate withblip (senza data, regole empiriche), bir.ch (08/08/2025, non parla di budget piccoli), pigeondigital (solo la soglia dei 50), creative-brackets (non sostiene "CBO default"); marcate le pagine jonloomer come "403 via fetch, letto da estratti"; aggiunte le pagine ufficiali Meta e tutte le fonti nuove citate sopra.
- Non inserito il presunto "irrigidimento dei reset ad aprile 2026" legato ad Andromeda: nessuna fonte primaria (audit).
- Non verificato, da ricontrollare a mano in un browser autenticato alla prossima manutenzione: le pagine ufficiali facebook.com/business/help 721422165168355 (AEM), 112167992830700 (fase di apprendimento), 942374239243867 (modifica significativa), 1523083297982009 (dimensione pubblici da sito), 153514848493595 (Advantage+ / flusso unificato); la pagina ufficiale sulla retention 730 giorni dei pubblici Acquisto (mai individuata, regola sostenuta solo da fonti secondarie); le pagine jonloomer.com (HTTP 403, lette solo da estratti dei motori di ricerca).
