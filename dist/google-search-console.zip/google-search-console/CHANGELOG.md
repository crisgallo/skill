# Changelog google-search-console

## 17/11/2026
- 🔴 Sez. 1, 6, 7 e sezione nuova «Stralcio in SERP (snippet)»: 4 saperi verificati in pratica (via Mother #28): avviso di indicizzazione dovuto a un sottodominio di staging, Breadcrumb con @id orfano, convalida fallita per la cache, stralcio della home governato con data-nosnippet.
- 🟡 Sez. 9: API Search Analytics con filtro brandedClassification (BRANDED/NON_BRANDED, dal 21/02/2026), tipo webMultimodal e filterLists.

## 13/11/2026
- 🟡 Sez. 4: anomalia dei dati 9-11/11/2026 sulle impressioni del report IA generativa (pagina ufficiale delle anomalie). Data in cima al 13/11/2026.

## 30/09/2026
- 🔴 Sez. 2, 4 e 9: regole di Cristiano misurate il 30/09/2026 su ScegliNatura (via chat di manutenzione): l'API Search Analytics con dataState final e 25.000 righe dà totali mensili identici al pannello (16 mesi su 16) e arriva più indietro (18/05/2025 contro 28/05/2025); le query visibili coprono il 32-53% dei clic; il filtro brand nativo (`%40BRANDED` / `%40NON_BRANDED`) è solo nel pannello, con dati dal 21/02/2026, e brand più non brand fa il totale; dal 24/09 un totale Web unico non si seleziona più e il rapporto IA generativa è solo nel pannello. Pagina API riletta (aggiornata l'11/08/2026): confermati type, dataState, rowLimit 25.000 e assenza di un filtro brand. Data di verifica al 30/09.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 2 punto 11 e sez. 4: filtro tipo di ricerca Web diviso in Text-based e Multimodal dal 24/09/2026 (Lens, Cerchia e cerca, immagine caricata, Chrome), senza dimensione Query (blog Search Central 24/09/2026, 7576553); September 2026 spam update dal 24/09 (Search Status Dashboard).
## 20/09/2026

- Prima stesura da fonti ufficiali: Search Console Help (34592, 9008080, 2451999, 7576553 e sotto-pagine 17010961/17011165/17011259/17011364, 7042828, 10268906, 16984139, 16983858, 16908024, 12945954, 7440203, 9012289, 7451001, 9205520, 11396518, 9049606, 9044175, 9044101, 9689846, 9679690, 9133276, 12917675, 12917991, 9370220); Search Central (guida site move, ai-features, What's new letto fino al 18/09/2026, blog 10/2022 sui limiti, blog 03/06/2026 report IA generativa, 29/07/2026 platform properties, 28/08/2026 site reputation EEA); API (searchanalytics.query, limits, how-to); Analytics Help 10737381 e 1308626; blog.google 03/06/2026 sui nuovi controlli.
- Non verificato: il tetto di richieste di indicizzazione giornaliere da Controllo URL (nessun numero ufficiale); il limite di 50.000 righe/giorno dell'API viene dal blog ufficiale del 2022 e non compare nella pagina limits del 2026; la pagina Help su vista 24 ore ed export non individuata; Search Engine Land 486269 in 403; 9128668 e 9128669 restituiscono pagine introduttive; nomi italiani esatti delle voci di menu 2026 (controllo IA generativa, rapporto IA generativa, annotazioni) da vedere sul pannello.
