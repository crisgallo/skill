# Changelog google-merchant-center

## 12/11/2026
- 🟡 Sez. 2: norma Misrepresentation riletta il 12/11/2026: vietato nascondere le condizioni della transazione (tempi di evasione, limiti al rimborso) prima dell'acquisto; offerte non disponibili senza sospensione immediata senza avviso. Data in cima al 12/11/2026.

## 05/11/2026
- 🟡 Sez. 4: Google for WooCommerce 3.8.1 o successiva per la Merchant API; impostazione delle etichette IA anche in Merchant Center, rinvio a google-ads-performance.
## 27/10/2026
- 🟡 Sez. 3: stesso obbligo di passkey su Google Ads dall'11/11/2026 (annuncio di servizio del 26/10); abbinamento in 1-2 giorni, piena attività dopo 7: la passkey si crea subito. Rimando a google-ads-performance sez. 13.

## 24/10/2026
- 🔴 Sez. 3: dal 29/10/2026 Merchant Center richiede una passkey per azioni sensibili (aggiungere utenti, assegnare permessi; l'accesso non cambia); la passkey di Google Ads vale anche qui; da creare prima del 29/10 su ogni Account Google che amministra un Merchant Center. Fonte: email di servizio Google del 22/10/2026, pagina ufficiale non trovata [DA VERIFICARE].

## 05/10/2026
- 🟡 Sez. 4: per WooCommerce la migrazione alla Merchant API richiede Google for WooCommerce 3.8.1 o successiva (documentazione WooCommerce letta il 05/10/2026).
## 28/09/2026
- 🟡 Sez. 1: le automazioni non funzionano sui prodotti che cambiano prezzo o disponibilità più di una volta al giorno, preorder/backorder compatibili con in_stock (3246284). Sez. 8: origini «inventario online» deprecate a favore delle supplementari (14990942). Fonti: troubleshooter prezzi 14280358 finalmente letto (albero interattivo, finestra di 48 ore del feed). Rilette senza cambi 12153802, 12159029, 12476548, 6069143, 6098334. Data di verifica al 28/09.
## 26/09/2026
- 🟡 Sez. 3, avviso prima della sospensione: le pagine Abuso della rete (6150118), Misrepresentation (6150127) e Alcol (12077694) sono cambiate il 26/09/2026 e ora dicono «7 or 28 calendar days to fix your issue»; la regola resta «almeno 7 giorni», aggiunta la precisazione. Rilette anche le terze parti sui nuovi Termini (Lemon Web, Searchen): nulla di nuovo rispetto alla sez. 3.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 12: la pagina delle norme Shopping unificate (annunci e schede gratuite) è online, vista il 25/09/2026, con le voci "solo Shopping ads" (6149970); le pagine Misrepresentation, abuso della rete, alcolici e salute sono rientrate nella stessa struttura senza cambi di regola.
## 21/09/2026
- Sez. 3: Termini di servizio letti sulla pagina ufficiale italiana (merchants.google.com/mc/termsofservice/merchant_center/IT/latest): "Ultima modifica: 1 June 2026"; il 15/06/2026 delle fonti terze resta come data di accettazione per uso continuato. Aggiunta la clausola sull'accesso e indicizzazione delle email di marketing; l'opt-out non è nei Termini. Aggiornate sez. 14 e 16 di conseguenza. Data in cima riscritta.
- Non verificato: dove sta l'opt-out nel pannello.

## 20/09/2026

- Prima stesura da fonti ufficiali: specifica dati prodotto (7052112) e aggiornamenti 2026 (16989427); registro annunci Merchant Center (6192467: 28/04, giugno, 15/07, 11/08/2026); aggiornamenti automatici (3246284); dati strutturati (6069143, merchant-listing su developers.google.com); disapprovazioni prezzo (6098334, 14916353, 15621352); GTIN e identifier_exists (6324461, 6324478, 6098295); norme Misrepresentation, Abuso della rete, Shopping, Salute, Alcol, Promozioni (6150127, 6150118, 6149970, 6150151, 12077694, 16796881); avvisi e sospensioni (12153802, 13693195); verifica sito (176793); collegamento Google Ads (6159060, 13717096, 13359353, 6275295); Merchant Center for Agencies (17072077); rebrand (17252069); origini dati (14990942, 12158480, 14994087, 15404838, 15624457, 14994083); spedizione, resi, valore minimo (6324484, 6069284, 10220642, 16989009); Qualità del negozio e badge (14261098, 15215732); schede gratuite (9199328); Richiede attenzione e stati (12476548, 12488713); report (9626903, 13299535, 17103877, 17117204); inventario locale (3057972); Merchant API (compatibility overview, latest updates: Content API spenta 18/08/2026, errori progressivi dal 01/09/2026); blog.google GML 2026.
- Non verificato: il testo dei Termini di servizio del 15/06/2026 e l'opt-out sulle email di marketing (solo fonti terze: searchen, lemon-web; la pagina 160173 è un indice); la finestra di avviso di 28 giorni (citata in snippet, non trovata su pagina letta); il troubleshooter prezzi 14280358 (albero interattivo non leggibile via fetch); i nomi italiani dei menu "Automazioni", "Richiede attenzione", "Correzioni prioritarie" e "Qualità del negozio" (dedotti dalle pagine inglesi, da confermare sul pannello); la dicitura dell'API usata dai plugin WooCommerce/Shopify nel dettaglio origine dati.
