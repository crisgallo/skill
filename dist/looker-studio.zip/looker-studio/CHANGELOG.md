# Changelog looker-studio

## 28/10/2026
- 🟡 Sez. 17: pagina Improve performance aggiornata il 26/10/2026: tabelle materializzate al posto delle viste pesanti, Storage Read API con i permessi readsessions, estratto 100 MB senza freschezza.

## 18/10/2026
- 🟡 Sez. 14: pagina embed riletta (agg. 13/10/2026): link solo dalla finestra Incorpora, larghezza e altezza, interruttore «Show report navigation in embedded mode», watermark e schermo intero fissi.
## 14/10/2026
- 🟡 Sez. 9: regola di Cristiano del 13/10/2026 (`feedback_report_e_numeri.md`, letta su Drive): ogni confronto mette i paragonati sullo stesso piano e con gli stessi fattori (finestra, periodo, definizioni, vista dei dati), altrimenti si rimanda.

## 29/09/2026
- 🔴 Sez. 10: regola di Cristiano dalla regola globale «Report e numeri per il cliente» del 28/09/2026 (`feedback_report_e_numeri.md`, promossa da Sceglinatura): report sempre mensili, confronto «prima di noi contro con noi», una fonte per numero (pannello che spende, gestionale, GA4 solo tendenze), niente dati provvisori né ROAS gonfiati, appendice sul metodo in coda. Fonti web e data di verifica invariate.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 1: release del 24/09/2026 (stile in blocco, PostgreSQL su IP privato, fine supporto MySQL 5.6 e 5.7 dal 26/02/2027, 13 connettori partner nuovi) dalle release notes ufficiali.
## 20/09/2026

- Prima stesura da fonti ufficiali: release notes Data Studio (rinomina Looker Studio → Data Studio del 16/04/2026, voci 01/06–13/08/2026), blog Google Cloud sulla rinomina, pagine docs.cloud.google.com su credenziali, trasferimento proprietà (20 giorni), connettori GA4 / Google Ads / Search Console / Fogli / BigQuery, troubleshooting quota GA4, campionamento GA4 in Data Studio, unione dati (how blends work, blending tips), campi calcolati, intervalli di date, filtri, parametri, freschezza e cache, auto refresh, componenti a livello di report, condivisione, embed, invio programmato, Pro (about-pro, try-pro, subscription overview, prezzo 9 USD/utente/progetto/mese dalla pagina cloud.google.com/data-studio), copia report, sostituzione origine, estrazione dati, prestazioni; Google Analytics Data API quotas e reporting data expectations; Help GA4 su riga (other), soglie, identità di reporting, compatibilità, freschezza; Help Google Ads su "Tutte le conversioni"; Help e API Search Console.
- Non verificato: soglia in cifra del campionamento della Data API (10 milioni di eventi citati solo da terze parti); pagina Help Search Console con i 16 mesi (letta solo via blog Search Central e community); account di servizio sul connettore Search Console (pagine ufficiali in contrasto); prezzo Pro in euro/IVA; vecchi URL support.google.com/looker-studio (404/redirect) e alcuni slug docs.cloud.google.com/looker/docs/studio (404, sostituiti dagli equivalenti sotto data-studio).
