# Changelog meta-pixel-capi

## 17/11/2026
- 🔴 Sez. 1, 2, 5, 11 e 13: 6 saperi verificati in pratica (via Mother #28): account nuovo aperto da un partner, «Genera token d'accesso» grigio per pixel personale, EMQ 0,0 per eventi fermi e dominio invalid.invalid, ID del pixel diversi dal feed con il modulo PrestaShop, eventi personalizzati della categoria salute e catalogo, valore degli acquisti in «Valore risultati».
- 🟡 Sez. 3: eventi offline via CAPI con action_source physical_store (Offline Conversions API «legacy»), parametro net_revenue per il margine, nessuna ottimizzazione sul margine documentata.

## 06/11/2026
- 🔴 Sez. 9: Marketing API v27.0 dal 04/11/2026; v24.0 disponibile fino al 10/11/2026 secondo la tabella del changelog (non 06/10); v25.0 fino al 23/02/2027.
## 03/11/2026
- 🟡 Sez. 8: termine di adeguamento alle Linee guida del Garante sui tracking pixel riscritto 29/10/2026 (sei mesi dalla GU del 29/04/2026), rinvio a brevo sez. 9.
## 30/10/2026
- 🟡 Sez. 5: rimandi aggiornati alla skill `gtm` (fino al 30/10/2026 `gtm-server-side`).
## 23/10/2026
- 🔴 Sez. 5: pagina ufficiale Meta 4237575203200036 letta dal sorgente: la misurazione sul dispositivo (voce «Measure conversions on customer devices», accesa per default) **non è attiva per le persone nell'UE e nel Regno Unito**; per un cliente italiano con pubblico UE dal 12/11 non cambia nulla; lavora accanto a Pixel e CAPI, attribuzione invariata; nota Stape del 22/10. Fonti aggiunte.

## 18/10/2026
- 🔴 Sez. 5: dal 12/11/2026 il Pixel recupera conversioni misurate sul dispositivo del cliente (email già data al sito più dati temporanei del dispositivo, che restano sul dispositivo), accesa per default sui dataset che inviano eventi, disattivabile in Gestione eventi; fonte la mail di Meta del 18/10/2026 a un account di Cristiano, pagina ufficiale non trovata, meccanica [DA VERIFICARE].
## 29/09/2026
- 🔴 Sez. 1: regola di Cristiano dalla chat Cowork di Sceglinatura dell'11/08/2026 (`feedback_nessuna_campagna_prima_della_capi.md`, ritoccata il 28/09): nessuna campagna si accende prima che la CAPI sia verificata in Gestione eventi (Browser e server), ordine di lavoro igiene GA4 → Stape → Meta → Google Ads → campagne. Fonti web e data di verifica invariate.
## 20/09/2026

- Prima stesura da fonti ufficiali: developers.facebook.com (parametri CAPI, evento server con finestra event_time 7 giorni e valori di action_source, customer information parameters e regole di hashing, deduplica event_id + event_name entro 48 ore, cookie _fbp/_fbc e costruzione da fbclid, using-the-api con batch da 1.000 e test_event_code, end-to-end con freschezza 1 ora, best practices EMQ, CAPI Tag per GTM server, offline events 62 giorni, app events, CAPI Gateway, riferimento Pixel con Purchase value+currency, conversion tracking con limiti 50 caratteri e 100 conversioni personalizzate, get started, Advanced Matching, GDPR fbq consent, data processing options LDU, Graph API changelog con scadenza Marketing API v24 il 06/10/2026), Business Tools Terms, annuncio Meta for Business del 15/04/2026 (Pixel con AI, CAPI abilitata da Meta), Shopify Help (livelli di condivisione dati), WooCommerce.com (Meta for WooCommerce), Stape helpdesk e blog, Garante privacy (provvedimento 284/2026).
- Allineata a `meta-ads-performance` sez. 4 (EMQ 6 come "buono", colonna Metodo di collegamento, event_id + event_name, v24 scadenza 06/10/2026, AEM web rimosso con annuncio 15/05/2023 e completamento metà 2025, iOS app ancora con eventi prioritizzati) e a `gtm-server-side` sez. 8 e `consent-mode-privacy` sez. 8 (LDU solo USA, fbq consent).
- Non verificato: tutte le pagine facebook.com/business/help (765081237991954 EMQ, 286768115176155 verifica dominio, 750785952855662 dataset, 952192354843755, 721422165168355 AEM, 348535683460989, 1624255387706033 e 2040882565969969 Testa gli eventi, 1993001664341800 e 611774685654668 Advanced Matching, 922442221236307 PrestaShop) restituiscono solo il titolo o errore via fetch; le fasce EMQ Scarso/OK/Buono/Ottimo sono di terzi; la durata del codice di test (24 ore) è di terzi; la pagina developers su EMQ (documentation/ads-commerce/conversions-api/event-match-quality) è arrivata troncata; le vecchie URL developers del CAPI Gateway e del payload helper sono 404; Signals Gateway non confermato su fonte Meta; distribuzione attuale e lista eventi del plugin Meta for WooCommerce; eventi server del modulo ufficiale PrestaShop; se il limite di 100 conversioni personalizzate è per account o per Business; etichettatura nel pannello degli eventi generati dalla CAPI abilitata da Meta.
