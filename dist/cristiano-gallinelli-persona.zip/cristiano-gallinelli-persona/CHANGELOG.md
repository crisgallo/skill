# Changelog cristiano-gallinelli-persona

## 29/09/2026
- 🔴 «Cosa Cristiano NON fa mai»: la regola di scrittura del 26/09 è stata estesa con la regola globale «La voce di Cris» del 28/09/2026 (`feedback_voce_di_cris.md`, promossa dal progetto Blog): dove vale (testi pubblici e a chi lo valuta, non le email di lavoro), periodo lungo più colpo breve e mai il telegramma, una cosa sola per tavola di carosello, ruoli, descrizioni e nomi copiati da LinkedIn parola per parola, «agenzia» vietata anche come web agency o studio, controllo di uscita completo. Fonti web e data «Ultima verifica sul blog» invariate.
## 26/09/2026
- 🔴 «Cosa Cristiano NON fa mai»: aggiunta la regola di scrittura dalle chat Cowork (`feedback_no_doppio_trattino.md` del 05/08/2026, confermata il 25/09/2026, e `feedback_testi_a_nome_di_cris_regole_prima.md` del 25/09/2026): niente trattino lungo o medio, al massimo un due punti per paragrafo, niente punto e virgola come colla, niente «·», «|», «//» come separatori, niente frasi che cominciano con «E»/«È», accenti veri, titoli di ruolo copiati da LinkedIn, con il controllo di uscita prima di consegnare. Caso: CV e lettera del 25/09/2026 bocciati. Le fonti web e la data «Ultima verifica sul blog» non cambiano.

## 24/09/2026
- «Cosa Cristiano NON fa mai»: aggiunta la regola dalla chat Cowork del 23/09/2026 (`feedback_mai_la_parola_agenzia.md`): mai «agenzia» per descriverlo, al suo posto consulente/consulenza/esperto; keyword con «agenzia» registrate come dato e scartate come terreno. Data di verifica sul blog invariata: non è una fonte web.
## 20/09/2026

- Aggiunta sotto l'H1 la riga «Ultima verifica sul blog: 20/09/2026» (articoli letti fino a «A corpo o a ore», 08/09/2026; prima stesura 14/03/2026).
- Aggiunta la sezione «0. Manutenzione» con feed, sitemap dei post e procedura di aggiornamento (titoli, lessico, temi, contraddizioni risolte a favore dei testi più recenti).
- Riscritto il punto 2 della proposta commerciale e il framework della consulenza strategica: il cliente porta il bersaglio, Cristiano non riformula il problema, chi non sa qual è il proprio problema non è un cliente (citazioni da «Se non sai qual è il tuo problema, non sei un mio cliente»).
- Aggiunto il modello di prezzo dichiarato in «A corpo o a ore» (a ore con tetto e rendiconto, a corpo solo diagnosi e audit, perimetro scritto, diritto di uscita) nel punto «Condizioni economiche» e nella biografia.
- Integrati come sfumatura «Il dato è un cadavere» / allenare gli esseri umani accanto a «Parte dai numeri, sempre» e «pornografia aziendale», con indicazione del registro (verifica a posteriori vs decisione).
- Integrato «L'ora è una comodità contabile» accanto a «Il tempo è denaro letteralmente», distinguendo la lente del tempo per le attività dalla lente del rischio per i contratti.
- Aggiunta in «Tono generale» la regola dei due registri (polemica sboccata vs inchiesta sobria con fonti e tabelle) con i trigger di ciascuno; aggiornate «Lunghezza» e «Blasfemia funzionale».
- Sostituita l'immunità al teatro dei social con l'auto-implicazione e la vigilanza dichiarata («Se smetto di vigilare, scivolo»); aggiunte le regole «mai ammorbidire la voce per il feed» e «non parla mai da fuoriclasse».
- Elevato lo skin in the game da prerequisito etico a criterio operativo unico («cosa ti succede se hai torto?») in «Come pensa» e in «Filosofia di fondo».
- Aggiunti alla «Filosofia di fondo» i temi nuovi: post mortem a rischio zero, marketing che si autocertifica, racconto vs depositato, Stuck in the Middle, sottobosco e vigilanza, mediocrità come asset, agenzie guscio e freelance per fame.
- Aggiunti a «Temi ossessivi» gli 11 titoli letterali di marzo-settembre 2026, «Zero e fatturati grazie a LinkedIn» e i precedenti citati nei post.
- Aggiunto a «Lessico caratteristico» tutto il lessico nuovo, verbatim e raggruppato per post d'origine.
- Aggiunte a «Strutture retoriche ricorrenti» dieci strutture nuove (seconda persona verso un ruolo, dichiarazione di metodo e conflitto d'interessi, ipotesi fallite, tabella e «Fonti», guida «Se compri / Se vendi», auto-implicazione e test a due domande, caso di cronaca con nomi, analogia estesa, domanda-sfida finale, costruzioni «Non è X, è Y» / «Chi X... chi Y»).
- Aggiornata «Meccanica della scrittura lunga» con le inchieste da 16-31 minuti e le chiusure a domanda-sfida, imperativo o «Fonti».
- Ampliati i «Riferimenti culturali» con vendita e consulenza, diritto e norme, dati di settore e persone del settore citate per nome.
- Aggiornata la modalità Project Management con «lo strumento è il pulsante», «Tutto verde fino all'incidente» e la planning fallacy.
- Aggiornata la biografia: conflitto d'interessi dichiarato su Websolute, regole scritte del Collettivo, autodescrizione da matematico, offerte del sito «Consulenza» e «Corso di statistica», newsletter Substack; mantenuti «Cultura del Dato per Adulti» (proposta Palabra) e Strateg.ee (confermati fuori dal blog).
- Ampliata «Cosa Cristiano NON fa mai» (non riformula il problema, non firma senza perimetro scritto, non commenta fallimenti altrui senza rischio, non ammorbidisce la voce sui social, non loda i fuoriclasse).
- Ampliati i «Riferimenti esterni» con feed, sitemap, Substack, canali, indirizzo e categorie del blog; segnalato «Veneto operativo» come non verificato sul blog.
- Aggiunta la sezione finale «Fonti» con gli URL e le date degli 11 post letti.

## 22/09/2026

- Spostata «Ultima verifica sul blog» al 22/09/2026 (articoli letti fino a «L'AI ti ruberà il lavoro. Ma magari!», 22/09/2026).
- Aggiunto a «Temi ossessivi» il titolo letterale «L'AI ti ruberà il lavoro. Ma magari!» (22/09/2026) come voce 22; «Precedenti citati nei post» diventa la voce 23.
- Aggiunto a «Lessico caratteristico» il lessico del post, verbatim (coglione a cui mollarlo, modello predittivo del weekend, R² di 0,97 come trofeo, Costa zero produrla costa uguale smontarla, La macchina non firma, funzione di perdita con partita IVA, intervalli vs numeri secchi, produrre carta, zero informazione dentro, il margine è una sottrazione, grimaldello, zerbino, Magari).
- Aggiunto a «Filosofia di fondo» il tema nuovo «L'AI ruba solo il lavoro di carta, e la macchina non firma», con citazioni verbatim e i riferimenti del post (Brandolini 2013, Shannon 1948, Taleb).
- Aggiunta a «Strutture retoriche ricorrenti» la struttura «titolo che ribalta il luogo comune e chiusura in una parola sola che lo richiama» (incipit in una frase, «Quello sono io.», «Magari.»).
- Aggiunto a «Fonti» l'URL del post del 22/09/2026.
