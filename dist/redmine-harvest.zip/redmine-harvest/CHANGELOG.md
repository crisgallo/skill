# Changelog redmine-harvest

## 06/11/2026
- 🟡 Sez. 8: prezzo mensile Harvest Teams senza impegno annuale 11 $ a posto (pagina pricing del 06/11); Enterprise mensile [DA VERIFICARE].
## 02/11/2026
- 🔴 Sez. 0 e 13: patch di sicurezza Redmine 7.0.3, 6.1.6 e 6.0.12 del 01/11/2026 (Security Advisories lette il 02/11): scope OAuth ignorato nel filtro dei progetti e ReDoS nelle macro wiki (alte), scope OAuth aggirati alla creazione di progetti e XSS riflessa in attachments#edit_all (moderate), validate_back_url (bassa); cosa chiedere all'agenzia che ospita Redmine.
## 20/10/2026
- 🟡 Sez. 2: regola di Cristiano del 20/10/2026 (`feedback_email_solo_bozza.md`, via manutenzione #16): le email si scrivono prima in chat, correzioni in chat, bozza Gmail solo col via libera e con il testo identico; il via libera non autorizza l'invio.
## 08/10/2026
- 🔴 Sez. 3: regola di Cristiano del 07/10/2026 (`feedback_email_solo_bozza.md`, globale): sul project Redmine di Webgriffe la chat scrive la nota e non salva, pubblica Cristiano; stato, assegnatario e percentuale non si toccano; dopo la pubblicazione si rilegge la versione salvata. Vale per Euroricambi, Takara e Shipminds.
## 01/10/2026
- 🔴 Sez. 0 e 13: Redmine 7.0.2 e 6.1.5 del 01/10/2026, tre falle di cui due nell'API REST (soggetti di segnalazioni private e nomi di progetti privati esposti) e una XSS DOM; Rails 8.1.4 / 7.2.4. Data di verifica al 01/10.
## 30/09/2026
- 🟡 Sez. 13: novità Harvest dell'autunno 2026 dall'articolo «In Season Fall 2026» del 29/09/2026: Time Off su tutti gli account, progetti Fixed Fee con canone mensile o milestone, dark mode, Gusto, rimborsi Stripe (USA), fatture Peppol/UBL in cinque paesi senza l'Italia; in beta Dashboards, Harvest AI e notification center. Nessun numero e nulla verificato sul pannello, quindi minore. Data di verifica al 30/09 (Redmine: nessuna novità sulle fonti).
## 20/09/2026
- Prima stesura da fonti ufficiali: wiki redmine.org (Rest_api, Rest_TimeEntries, Rest_Issues, Rest_api_with_curl, RedmineTimeTracking, RedmineTimelogDetails, RedmineTimelogReport, RedmineIssues, RedmineIssueTrackingSetup, RedmineIssueList, RedmineMyPage, RedmineRoles, RedmineProjectSettings, RedmineCustomFields, RedmineSettings, RedmineWikis, RedmineDocuments, Changelog_6_0/6_1/7_0, news e news/161); codice Redmine su GitHub (mailer.rb, issue_edit.text.erb, settings.yml, en.yml, it.yml) per oggetto/corpo/intestazioni delle notifiche, default delle impostazioni e nomi italiani dei menu; Harvest API v2 (authentication, general, pagination, time entries, projects, company, invoices, time reports, uninvoiced, project budget); getharvest.com/pricing e /forecast; blog Harvest "Inside the new Harvest" (05/05/2026) e "In Season Summer 2026" (15/07/2026).
- Non verificato: tutte le pagine di support.getharvest.com (403 via fetch: budget, avvisi budget, report ed export, report salvati/condivisi, custom report, export Google Drive, sblocco voci fatturate, Harvest MCP, piani) sono citate solo dagli estratti dei motori di ricerca; changelog API Harvest (404); RedmineUserAccounts (404); `user_id=me` sulle voci di tempo via API; nomi dei campi ore spese nella singola issue via API; accettazione di `external_reference` in POST /v2/time_entries; prezzo mensile Harvest senza impegno annuale e soglie della componente a consumo; costo di Forecast (solo fonti terze); esportazione UBL verso SDI.
