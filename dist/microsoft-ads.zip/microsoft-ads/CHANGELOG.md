# Changelog microsoft-ads

## 05/11/2026
- 🟡 Sez. 2: Clarity del 04/11/2026: Agent Activity, Conversational Analytics, Brand Agents (post Microsoft Advertising), disponibilità [DA VERIFICARE].
## 01/11/2026
- 🟡 Fonti: etichetta StatCounter aggiornata a ottobre 2026 (CSV letto il 31/10).
## 31/10/2026
- 🔴 Sez. 2, 10 e 13: post ufficiale Microsoft del 27/10/2026: Conversions API disponibile a tutti (server-to-server accanto all'UET, via GTM o partner come Stape), PMax con targeting per età e genere, dispositivi in arrivo, report termini di ricerca e approfondimenti sull'asta, pagina di destinazione da metà novembre, messaging guidelines in pilota aperto (fino a 40 regole), creazione guidata dall'AI; marcati [DA VERIFICARE] deduplica e nomi dei menu. 🟡 Sez. 7: quota StatCounter Italia di ottobre 2026 (Bing 5,83%).
## 26/10/2026
- 🔴 Sez. 9: regola di Cristiano del 25/10/2026 (`feedback_piattaforme_e_campagne.md`, via manutenzione #17): ogni annuncio nasce con parametri URL dello standard del progetto, URL finale sulla pagina giusta, invito all'azione dove il formato lo prevede e prova dopo la pubblicazione; brief senza i quattro punti rifiutati dal controllo automatico.

## 01/10/2026
- 🔴 Sez. 9 e 13: post prodotto del 30/09/2026: liste aziende LinkedIn da 1.000 a 10.000 nomi, integrazione HubSpot in GA, Optimization Experiments in GA su Search/Shopping/Audience/PMax, API SOAP dismessa il 31/01/2027.
- 🟡 Sez. 7: StatCounter Italia settembre 2026 (Google 87,31%, Bing 5,97%, Yahoo 5,00%, DuckDuckGo 0,69%). Data di verifica al 01/10.
## 20/09/2026

- Prima stesura da fonti ufficiali: pagine help Microsoft Advertising lette sullo specchio learn.microsoft.com/advertising/msa-help (consenso UET e FAQ, setup UET e stati del tag, conversioni avanzate, cosa viene importato da Google Ads, importa campagne, import programmati, tipi di corrispondenza, generica, strategie di offerta, opzioni di budget, budget condiviso, rete Microsoft Advertising, distribuzione annunci, esclusioni, annunci in Copilot, FAQ remarketing, in-market, LinkedIn profile targeting, Customer Match, RSA, best practice Performance Max, upgrade DSA → PMax, import da Google Merchant Center, tasse e IVA, auto-apply), guida API import Google Ads e RSA, release notes API (13.0.29 del 04/08/2026), documentazione Clarity (UET e Clarity, 08/09/2026), blog about.ads.microsoft.com (AI Max GA 27/08/2026, product news agosto, giugno e aprile 2026, recap Activate 2026, "tre ere del web" aprile 2026, BMM maggio 2021, policy giugno 2023), pagina supporto Italia, Q&A Microsoft su IVA in fattura e traffico syndicated.
- Fonti terze dichiarate come tali: StatCounter Italia agosto 2026 (quote Bing/Yahoo/DuckDuckGo), seroundtable e digitalapplied (AI Max, Max CPC dal 01/10/2026), ppcnewsfeed (policy salute 07/2026, servizi governativi 08/2026, Shopping in Copilot 12/09/2026, import NCA 04/2026), Search Engine Land (auto-apply di default).
- Non verificato: le pagine help.ads.microsoft.com con URL `#apex` non sono leggibili via fetch (rispondono con pagina vuota); pagina mercati e disponibilità funzioni per l'Italia (hlp_BA_CONC_Countries: 404), changelog policy ufficiale (404), policy gioco d'azzardo e farmacia (404, quindi stato Italia marcato [DA VERIFICARE]), pagina "cosa succede al limite di budget" (404); blocco Italia dentro la pagina tasse e IVA non isolabile (emittente fattura marcato [DA VERIFICARE]); estensioni immagine non importate da Google (solo fonti terze); default AI Max sulle nuove campagne (blog ufficiale dice attivo di default, fonte terza dice opt-in: da vedere sul pannello); disponibilità in Italia di in-market e formati conversazionali Copilot; Search Engine Land 485530, 394340 e 443000 in 403; nessun post prodotto di luglio 2026 trovato sul blog.
