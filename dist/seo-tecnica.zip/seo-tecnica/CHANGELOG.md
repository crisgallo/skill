# Changelog seo-tecnica

## 09/10/2026
- 🟡 Sez. 14: September 2026 spam update completato l'08/10/2026 (14 giorni), dalla dashboard di stato di Google Search.
## 02/10/2026
- 🟡 Sez. 14: spam update di settembre 2026 ancora in corso al 02/10, seconda ondata del 30/09 (fonte terza); pagina creating-helpful-content aggiornata il 01/10/2026 (chi, come, perché; automazione). Data di verifica al 02/10.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 14: September 2026 spam update dal 24/09/2026 (Search Status Dashboard) e regola di lettura di un calo dal 24/09. Sez. 6: VideoObject con creator/author e interactionStatistic chiariti (documentazione 24/09/2026); filtro multimodale in Search Console (blog Search Central 24/09/2026).
## 23/09/2026
- Sez. 7: pagina page experience aggiornata il 22/09/2026 con le metriche sperimentali CrUX sugli annunci (numero, densità, peso).

## 20/09/2026

- Prima stesura da fonti ufficiali: Google Search Central (robots.txt intro e specifica, noindex, canonicalizzazione, codici HTTP e redirect, trasferimento sito con cambio URL, navigazione a faccette, paginazione e struttura URL e-commerce, crawl budget, sitemap e sitemap immagini, hreflang, galleria e pagine dei dati strutturati Product/Merchant listing/Organization/Breadcrumb/Article/FAQPage, Core Web Vitals e page experience, JavaScript SEO e rendering dinamico, title link, snippet, SEO starter guide, Google Immagini, operatore site:, contenuti utili, guida ai sistemi di ranking, policy spam con aggiornamento site reputation del 28/08/2026, AI features, guida all'ottimizzazione per l'IA generativa del 15/05/2026, core update, pagina degli aggiornamenti della documentazione e indice del blog); guida Search Console (rapporto Indicizzazione delle pagine 7440203, Cambio di indirizzo 9370220, rapporto CWV 9205520); web.dev/vitals; Search Status Dashboard (summary) per le date dei ranking update 2025-2026; blog.google sui controlli IA per i siti (03/06 e 31/08/2026).
- Non verificato: corpo del post del Search Central Blog di giugno 2026 sui rapporti IA generativa (solo titolo; contenuto preso da Search Engine Journal e dai risultati della guida 16984139); corpo del post di agosto 2023 su HowTo/FAQ (contenuto preso dalle note della pagina FAQPage); pagine della guida Search Console 16984139 e 16908024 viste solo tramite risultati di ricerca; storico completo della Search Status Dashboard (404, usata la pagina summary); paragrafo della guida ai trasferimenti sul mantenere una sitemap con i vecchi URL (marcato [DA VERIFICARE]); finestra di 28 giorni di CrUX (marcata [DA VERIFICARE]); nomi esatti dei menu italiani di Search Console per il rapporto e l'interruttore dell'IA generativa (sez. 17).
