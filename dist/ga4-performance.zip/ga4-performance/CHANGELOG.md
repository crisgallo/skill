# Changelog ga4-performance

## 26/11/2026
- 🟡 Sez. 9: sapere via Mother (26/11): un'esplorazione aperta per leggere i dati resta salvata nella proprietà del cliente, da eliminare a mano o da evitare usando i rapporti standard.

## 21/11/2026
- 🔴 Sez. 0: note di rilascio di ottobre-novembre 2026 (lette il 21/11/2026): Data Manager in Google Analytics (beta, hub in Amministrazione per collegamenti, stream e dati di prima parte), diagnostica dei dati forniti dall'utente, User Groups Admin API, agent skills Firebase.

## 17/11/2026
- 🔴 Sez. 2, 4, 5, 8, 9 e tre sezioni nuove (Pubblici e dimensioni personalizzate; page_view doppi sui siti editoriali; Lettura dei numeri, casi): 17 saperi verificati in pratica dalle chat di progetto (via Mother #28): IPv6 nel traffico interno, filtri regex sugli eventi nuovi, raccolte, preset 28 giorni, limiti dei nomi, costruttore di pubblici, archiviazione delle dimensioni, link diretti, ruolo ereditato, Cestino, eventi a passi, nomi troncati, page_view doppi e misura su BigQuery, prodotti con due nomi, rimborsi negativi, categoria salute.

## 12/11/2026
- 🟡 Sez. 7: sezione Pubblicità secondo la pagina ufficiale riorganizzata (prodotti da collegare, report Istantanea, Percorsi di attribuzione, Rendimento delle conversioni, report per prodotto, Annunci publisher; dimensione Integrazione nel Report view). Data in cima al 12/11/2026.

## 07/11/2026
- 🔴 Sez. 7: Data Manager in Google Analytics (beta) dal 06/11/2026, hub unico in Amministrazione per stream, collegamenti e importazioni, mappa delle connessioni con pulsante Correggi; avviso sul doppio conteggio se la stessa importazione è attiva anche in Google Ads. Sez. 0 e Fonti aggiornate; data in cima al 07/11/2026.

## 10/10/2026
- 🟡 Sez. 0: nota di rilascio del 05/10/2026, User Groups Admin API per gestire i gruppi di utenti via API; nessuna regola cambiata.
## 02/10/2026
- 🔴 Sez. 4: regola di Cristiano verificata sul pannello il 01/10/2026 (chat di manutenzione): «Nuovo evento chiave» non esiste più; evento chiave anticipato con «Crea evento» + «Contrassegna come evento chiave» + «Crea con codice»; trappola del valore predefinito 1 USD che si salva anche scegliendo «Non impostare», correzione dal menu della riga. Riga estesa, 399 righe.
## 01/10/2026
- 🟡 Sez. 0: interruzione del pannello GA4 del 29/09/2026 sera (ora USA), circa un'ora, fonte terza; controllo del 30/09 nei report di settembre prima di parlare di calo. Data di verifica al 01/10.
## 30/09/2026
- 🟡 Sez. 0: nota di rilascio del 29/09/2026 (9164320): le conversioni delle app entrano pienamente nei report di conversione (rendimento, analisi e modelli di attribuzione) per i clienti Google Ads; nessuna regola cambia per chi misura solo siti web. Il filtro Hostname in modalità Includi del 21/09 era già in sez. 2. Data di verifica al 30/09.
## 29/09/2026
- 🔴 Sez. 1: regola di Cristiano dalla chat Cowork del Blog dell'11/08/2026, promossa a sapere globale il 28/09/2026 (`feedback_eventi_chiave_incrociare_col_container.md`): gli eventi chiave si puliscono incrociando la lista con gli Eventi recenti e con i tag del container GTM, mai guardando solo la lista; gli eventi della misurazione avanzata non si marcano come conversione; allineamento sui tre pannelli. Fonti web e data di verifica invariate (riga estesa, la skill resta a 399 righe).
## 28/09/2026
- 🟡 Sez. 8, limiti: aggiunti 10 dimensioni a livello articolo, 5 metriche calcolate, 24-48 ore prima di poter usare una definizione nuova e 48 ore di attesa dopo una cancellazione al limite (pagina 14240153 cambiata il 28/09/2026). Rilette senza cambi di regola le pagine 10104470, 13296662 (filtri dati, 10 per proprietà, 24-36 ore) e 7201382 (DebugView). Data di verifica al 28/09.
## 23/09/2026
- Sez. 6: aggiunta la regola di Cristiano dalla chat Cowork del 19/09/2026 (Sceglinatura, `feedback_numeri_dal_pannello_non_da_ga4.md`): i numeri di spesa e risultato si leggono nel pannello che spende, GA4 solo per tendenze ed esplorazioni; le due fonti non si mescolano in una tabella. Con i numeri del caso (acquisti senza sorgente 92% e 89%, google/cpc 1 e 0 contro 120 e 93). Data di verifica delle fonti invariata: non è una fonte web.
- Sez. 5: limiti delle Dashboard (15 schede standard, 30 su 360, ruoli Editor e Amministratore, condivisione a tutta la proprietà, niente API, segmenti e confronti) dalla pagina 17217303.

## 22/09/2026
- Sez. 2: dal 21/09/2026 il filtro Hostname ha anche la modalità Includi (allowlist di domini); non copre il Measurement Protocol; hostname vuoti bloccati (note di rilascio GA4, https://support.google.com/analytics/answer/9164320). Data in cima riscritta.

## 20/09/2026

- Partita dalla copia locale dell'autore del 19/09/2026 (che ha aggiunto l'osservazione sulla stella grigia di `purchase` sulla proprietà Sceglinatura), non dalla copia claude.ai del 12/08/2026. Aggiornata la data in testa a 20 settembre 2026.
- Sezione 0: aggiunto il blocco "Cosa è cambiato il 20/09/2026" con le correzioni, i `[DA VERIFICARE]` chiusi e le novità di agosto-settembre 2026 con date e URL; il 🔴 sui `[DA VERIFICARE]` ora dice che ne resta uno solo (cardinalità).
- Sezione 7: corretta la regola UTM contro auto-tagging, che era capovolta. Con auto-tagging attivo vincono i valori auto-taggati, non esiste override, gli UTM non rompono l'importazione delle conversioni; il rischio vero è l'auto-tagging spento (https://support.google.com/analytics/answer/11242870, https://support.google.com/analytics/answer/10723328). Aggiunta la diagnostica gbraid/gad_ del 30/07/2026 e la distinzione conversioni/eventi chiave (13965727).
- Sezione 6: corretti i modelli di attribuzione, che sono tre (basato sui dati, ultimo clic a pagamento e organico, ultimo clic canali a pagamento Google), rimozione degli altri a novembre 2023 (https://support.google.com/analytics/answer/10596866). Separato il cambio di modello, retroattivo, dal cambio di finestra, che vale solo in avanti (https://support.google.com/analytics/answer/10597962, https://support.google.com/analytics/answer/16291704).
- Sezione 6: chiuso il `[DA VERIFICARE]` sulle finestre di lookback (acquisizione 30 o 7, altri 90 o 30/60, engaged-view 3; https://support.google.com/analytics/answer/16291704). Aggiunte le finestre di conversione personalizzate dell'11/08/2026 (1-90 click-through, 1-30 engaged-view) in Pubblicità > Gestione conversioni.
- Sezioni 3 e 6: riscritto il thresholding. Non dipende più da "Google Signals nell'identità dei report": scatta su demografia e query di ricerca, le identità mista e osservata sono soggette a soglie (https://support.google.com/analytics/answer/9383630, https://support.google.com/analytics/answer/10976610). Dal 15/06/2026 Google Signals governa solo l'associazione con gli utenti loggati, i cookie Ads dipendono dal Consent Mode (https://support.google.com/analytics/answer/17016975). In sezione 3 lasciato solo il rimando.
- Sezione 8: corretta la conservazione dei dati, che non tocca i confronti nei report standard ma solo esplorazioni e canalizzazioni; aggiunti opzioni 2/14 mesi, 24 ore di attesa reversibili, 2 mesi fissi per età/genere/interessi, riduzione automatica a 2 mesi per proprietà Large (https://support.google.com/analytics/answer/7667196).
- Sezione 2: corretta l'esclusione dei referral. Stesso dominio e sottodomini sono già esclusi da soli; il traffico escluso eredita la sorgente precedente se c'è, altrimenti va in diretto; 50 voci per stream (https://support.google.com/analytics/answer/10327750). Allineato il punto 6 della sezione 9 e la voce in sezione 10.
- Sezione 2: aggiunte le fonti dell'ordine regola-filtro, del parametro `traffic_type`, degli stati e della non retroattività (https://support.google.com/analytics/answer/10104470, 13296662, 13296761, 16608575), il limite di 10 filtri e il filtro Hostname dell'11/06/2026 (13296761, note di rilascio 9164320). Segnato che il filtro nato in Test resta osservazione di pannello.
- Sezione 1: chiuso il `[DA VERIFICARE]` sul numero massimo di eventi chiave (30 standard, 50 per 360; https://support.google.com/analytics/answer/13128484, 12229528). Agganciata la citazione ufficiale sulla non retroattività e la latenza fino a 24 ore nei report standard (13128484); aggiunti 12844695 (percorso eventi chiave) e 9216061 (misurazione avanzata). Marcato come criterio di metodo "solo se ha un tag suo" e come osservazione di pannello "`purchase` compare anche senza e-commerce". L'osservazione del 19/09/2026 sulla stella grigia è rimasta intatta.
- Sezione 3: chiuso il `[DA VERIFICARE]` sul campionamento (10M eventi per query su standard, 1B su 360; https://support.google.com/analytics/answer/13331292, 13888627). Aggiunte le fonti su privacy e condivisione delle esplorazioni e i limiti 200/500/10/10 (7579450, 12229528), la conferma documentale dei preset mobili, la copia fra proprietà (15401228), la precisazione che "non si creano via API" vale per assenza, e le Dashboard del 09/09/2026 come terza via (17217303).
- Sezione 4: nessuna modifica alla meccanica. Appesa una nota datata 20/09/2026 da ricontrollare a mano: nuova dimensione Source group dall'11/06/2026 e conteggio 364/168 probabilmente cambiato.
- Sezione 5: nessuna modifica alla meccanica dell'editor. Appesa una nota datata 20/09/2026 sul pulsante "+ Crea > Dashboard" nel menu Report dal 09/09/2026 (17217303). Nella parte di dominio: fonti su raccolte e limiti 7/5/10 (10460557), 12 metriche e 150 report personalizzati (10445879), 255 caratteri marcato come osservazione; aggiunte la raccolta automatica Google Business Profile dell'08/06/2026 e la controindicazione su *Costo non Google* per chi importa costi (valuta obbligatoria 28/07/2026, report di validazione 10/08/2026; note di rilascio 9164320).
- Sezione 7: aggiunte le fonti del collegamento Google Ads (9379420) e Search Console (10737381, 13682862, 13682863, con vincolo uno-a-uno, 16 mesi, 48 ore). L'ID misurazione statico in GTM resta osservazione di prima mano, con la diagnostica *Missing Google tags* come controprova (tagmanager 13543899, 12131703, 14681508).
- Sezione 8: il `[DA VERIFICARE]` sulla cardinalità resta aperto con la nota che Google non pubblica il numero, solo ">500 valori = alta cardinalità" (https://support.google.com/analytics/answer/13208658). Chiuso il `[DA VERIFICARE]` sui limiti: 50/50/25 definizioni personalizzate, 25 parametri per evento, 40 caratteri per nomi evento e parametro (12229528, 9267744).
- Sezione 9: aggiunti il filtro Hostname al punto 2, la raccolta Google Business Profile al punto 7, finestre e Consent Mode al punto 9, il rimando ai limiti al punto 10.
- Sezione 10: corretti "diventa diretto" e "cambio di modello di attribuzione" (ora "finestra di lookback o di conversione"); aggiunta la voce sugli UTM manuali su URL auto-taggati; aggiunta la Dashboard come alternativa all'esplorazione distribuita.
- Fonti: sostituito il paragrafo "Da fare al primo giro di manutenzione" con l'elenco degli URL ufficiali usati, raggruppati per sezione.
- Non verificabile su fonte ufficiale, lasciato come osservazione di prima mano: ID misurazione statico in GTM, limite di 255 caratteri della descrizione di un report, filtro dati che nasce in stato Test, `purchase` nell'elenco di un sito senza e-commerce, esplorazioni non creabili via API; e la soglia numerica di cardinalità, che Google non pubblica.
