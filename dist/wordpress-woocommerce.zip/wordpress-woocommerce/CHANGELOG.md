# Changelog wordpress-woocommerce

## 14/11/2026
- 🔴 Sez. 1: requisiti raccomandati WordPress, MySQL 8.4 o superiore al posto di 8.0 (pagina ufficiale riletta il 14/11/2026). Data in cima al 14/11/2026.

## 12/11/2026
- 🔴 Sez. 2: patch di sicurezza del WooCommerce Stripe Gateway dell'11/11/2026 (11.2.0 o 11.1.2; acquisti fraudolenti; password in chiaro negli ordini con la 10.9.0, pulizia e avviso dalla 11.1.0; richiede WordPress 6.9 e WooCommerce 11.0; procedura di verifica e di downgrade controllato). 🔴 WooCommerce 11.3.0 dell'11/11/2026 (aggiornamento DB, On-Sale Badge, pagina Rimborsi e resi con dati strutturati, REST API e MCP). 🟡 CISA KEV del 03/11: CVE-2026-119977 di WordPress core sfruttata attivamente. Data in cima al 12/11/2026.

## 07/11/2026
- 🔴 Sez. 2: post Woo del 06/11/2026 sulla sicurezza: da WooCommerce 11.2 le release di sicurezza «richieste» delle estensioni del Marketplace si installano da sole sui negozi collegati con abbonamento attivo anche con gli automatici spenti; release di sicurezza dedicate (Critical/High nella patch successiva, Medium/Low dopo la minor); PHP 7.4 e 8.0 supportati fino alla 11.5, 11.6 (febbraio 2027) richiede 8.1+; controllo della versione dopo ogni patch, staging compresi.
- 🟡 Sez. 1: precisato che il PHP 8.3+ dei requisiti è il raccomandato, il minimo tecnico è più basso. Fonti e data in cima al 07/11/2026.

## 05/11/2026
- 🔴 Sez. 1: WooCommerce 11.2.2 del 04/11/2026, release di sicurezza con aggiornamento del database (Store API, chiavi REST, attributi, checkout, CSV, endpoint wc-admin); cosa fare e cosa può rompersi.
## 04/11/2026
- 🔴 Sez. 2: aggiornamento di sicurezza WooPayments del 03/11/2026 (funzione abbonamenti, estende la correzione di agosto), tabella delle versioni corrette e cosa fare su ogni negozio.
- 🟡 Sez. 0: calendario 7.2 riletto il 04/11 (Beta 3 il 28/10 con la 7.1.4, Beta 4 il 03/11, Beta 5 il 10/11, RC3 l'01/12); uscita confermata l'08/12/2026.
## 03/11/2026
- 🔴 Sez. 2: WordPress 7.1.4 del 28/10/2026, release di sicurezza a ciclo breve (esecuzione di codice remoto nella finestra di upgrade, XSS memorizzati multipli, DoS nell'Interactivity API, changeset del Customizer leggibili senza login): verificare 7.1.4 o successiva su ogni sito cliente, aggiornare il giorno stesso dove l'auto-update è spento. Sfuggita ai giri dal 28/10 perché la pagina della release non era fra gli URL fotografati.
## 27/10/2026
- 🟡 Sez. 1: WooCommerce 11.3 in beta dal 26/10/2026, rilascio nella settimana del 09/11; rimozione dell'endpoint MCP deprecato a favore del WordPress MCP Adapter (post del 21/10), avvisi su PHP < 8.1.

## 24/10/2026
- 🟡 Sez. 1: avviso informativo php.net del 23/10/2026 su session upload progress (CVE-2026-115560): nessuna release nuova, la mitigazione `session.upload_progress.enabled=0` del 21/10 resta al suo posto; riguarda solo chi cambia il serialize handler a runtime. Fonte aggiunta.

## 22/10/2026
- 🔴 Sez. 1: avviso di sicurezza php.net del 21/10/2026 (due RCE critiche senza autenticazione, CVSS 9.2): versioni corrette 8.2.35, 8.3.36, 8.4.27, 8.5.12; controllo della versione PHP in Salute del sito e aggiornamento immediato tramite l'hosting; siti su 8.1 o inferiore da spostare su 8.3 subito.
## 18/10/2026
- 🟡 Sez. 1: WooCommerce 11.2.1 del 09/10/2026 (non di sicurezza): indirizzo nel checkout classico e CAP nel checkout a blocchi.
## 14/10/2026
- 🟡 Sez. 0: calendario di WordPress 7.2 con le date ufficiali (Beta 1 20/10, RC1 17/11, code freeze 07/12, rilascio 08/12/2026).

## 10/10/2026
- 🟡 Sez. 0: WooCommerce 11.2.1 del 09/10/2026, correttiva (checkout classico senza campi indirizzo, CAP nel checkout a blocchi), senza fix di sicurezza né aggiornamento del database.
## 08/10/2026
- 🔴 Sez. 0: WooCommerce 11.2.0 del 07/10/2026 con fix di sicurezza (Cc/Ccn sulle email di account, link di download, permessi degli shop manager, Blueprint solo da super admin su multisito, tracking d'uso), aggiornamento del database richiesto, conflitto con PublishPress Future fino a 4.10.3; novità: email di recesso, CSV per GTIN, campi data nel checkout. Release notes ufficiali lette l'08/10/2026.
## 07/10/2026
- 🔴 Sez. 0: WordPress 7.1.3 del 06/10/2026, release di sicurezza con 7 falle (fra cui lettura senza login dei commenti di post privati, SQL injection nell'export WXR, XSS in Commenti e negli embed Imgur) e 4 bug; backport fino alla 4.7; su ogni sito cliente si verifica la 7.1.3 e si aggiorna il giorno stesso dove l'auto-update è spento.
## 01/10/2026
- 🔴 Sez. 7: regola di Cristiano (chat di manutenzione, `wordpress.md`, 01/10/2026): procedura per modificare uno snippet WPCode da Chrome senza rischiare il sito (controllo anti cache, copia in localStorage con somma di controllo, replaceRange su marcatore, CRLF, cache x-ac, form agganciati). Non verificata su editor diversi da CodeMirror.
- 🟡 Sez. 0: calendario WordPress 7.2 (Beta 1 20–22/10, RC1 17–19/11, code freeze 7–9/12, rilascio 8–10/12/2026) dalla pagina ufficiale; Gutenberg 24.1 del 30/09 (strumenti di design uniformi fra blocchi, nessuna regola cambia). Doc Google for WooCommerce riletta: invariata (3.8.1 per la Merchant API già scritto). Data di verifica al 01/10.
## 29/09/2026
- 🔴 Sez. 3: regola di Cristiano dalle chat Cowork del Blog (05-07/08/2026), promossa a sapere globale il 28/09/2026 (`feedback_wp_ereditare_stile_blocchi.md`): un blocco o un campo nuovo non eredita lo stile dei vicini, si copiano attributi e classi da un elemento fratello e si verifica lo stile calcolato. Fonti web e data di verifica invariate.
## 28/09/2026
- 🔴 Sez. 2: WordPress 7.1.2 del 22/09/2026, release di sicurezza di gravità critica (inclusione di file PHP locale nella risoluzione dei template, CVE-2026-87902), backport fino alla 4.7, auto-update in background: su ogni sito cliente si controlla la versione 7.1.2 o successiva. Trovata il 28/09 tramite la pagina del plugin Two-Factor (0.17.0, «tested up to 7.1.2») e confermata sul post ufficiale wordpress.org/news.
- 🟡 Fonti: pagina GTM 14842164 ora letta (un container per sito, nome = URL principale). Rilette senza cambi la doc Google Analytics for WooCommerce, il post di WordPress 7.1 e la pagina del plugin Two-Factor. Data di verifica al 28/09.
## 23/09/2026
- Sez. 1: WooCommerce 11.1.2 del 22/09/2026 (changelog ufficiale).
- Sez. 8: Google for WooCommerce almeno 3.8.1 per la Merchant API; Google Analytics for WooCommerce non dismesso (doc ufficiali).

## 22/09/2026
- Sez. 1: WooCommerce 11.2.0 in beta dal 21/09/2026 (email di recesso configurabili, CSV per GTIN); solo staging (changelog ufficiale). Data in cima riscritta.

## 20/09/2026

- Prima stesura da fonti ufficiali: wordpress.org (requisiti, Settings Reading, permalink, releases 2026 con 7.0 del 20/05, 7.1 del 19/08 e 7.1.1 di sicurezza del 17/09), make.wordpress.org (tabella PHP/WordPress del core handbook aggiornata 19/08/2026 con ritiro dell'etichetta "beta support" a maggio 2026, tabella del team hosting, sitemap 5.5, Site Health cache checks 6.1, schedule 7.2), developer.wordpress.org (upgrading e auto-update, hardening, migrating, wp search-replace, filtro xmlrpc_enabled, optimization), developer.woocommerce.com (changelog, release calendar, note di 11.0, 11.1 e 11.1.1, politica L-1, configurazione cache), woocommerce.com/document (server requirements, HPOS, Cart/Checkout blocks, Google for WooCommerce e setup, Google Analytics for WooCommerce, Meta for WooCommerce, WooPayments paesi, tasse), wordpress.com/support e blog (plan features, plugins su tutti i piani a pagamento dal 02/04/2026, changelog 08/05/2026, Google Analytics, sitemaps, feeds, staging, Blaze e crediti), php.net supported versions, Google (GA4 ecommerce, WooCommerce Google tag 12973528, Site Kit Tag Manager), iubenda, Complianz, Cookiebot su wordpress.org, issue GitHub #4047 di Meta for WooCommerce.
- Non verificato: pagina support.cookiebot.com sull'installazione WordPress (403); pagina Site Kit "managing Tag Manager" (404, usata la pagina supported-services); corpo della guida GTM "install web container" (14842164); guida "Update PHP" su developer.wordpress.org (404); pagina budget Blaze (404, dati da promote-a-post e blaze-credits); guida sync staging WordPress.com; doc WooCommerce sulle aliquote IVA UE digitali; elenco eventi standard di Meta for WooCommerce (assente dalla doc); deduplicazione GA4 su transaction_id nella stessa sessione; installabilità di Site Kit su piano Personal WordPress.com; plugin di fatturazione elettronica citati solo come fatti di prodotto dalle pagine dei produttori.
