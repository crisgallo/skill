# Changelog trustpilot

## 14/11/2026
- 🔴 Sez. 4: quota di inviti per mese di calendario con azzeramento il 1°, conteggio alla data di invio effettivo, inviti combinati, stato «Limite raggiunto» non riprogrammato da solo, controllo di metà mese e riprogrammazione al mese dopo (risposta del supporto Trustpilot del 13/11/2026). Data in cima al 14/11/2026.

## 01/10/2026
- 🔴 Sez. 2, 3, 6, 13: Guidelines for Businesses v7.3 (settembre 2026) al posto della v7.2: contenuto AI fra i motivi di segnalazione, software di rilevazione sulle segnalate; aggiunte le regole ufficiali già presenti ma mai scritte qui: tre giorni al recensore prima di segnalare "non basata su esperienza reale" e una sola recensione per recensore nel TrustScore.
- 🟡 Listino (pricing USD) riletto il 01/10: invariato. Data di verifica al 01/10.
## 25/09/2026
- Data di verifica a 25 settembre 2026. Sez. 13: Product updates del 24/09/2026 (pagine recensione per prodotto, QR Code Collector, Location Reviews e API, Review Follow-up Targeting, Search Query Data, AI Search Market Insights, Multi-Domain e Custom Roles solo Enterprise).
## 24/09/2026
- Listino riletto il 24/09/2026 (plans USD, plans IT, pricing): prezzi e inviti invariati; TrustBox Enterprise da 22 a 23; aggiunta la prova gratuita di 14 giorni del piano Plus. Data di verifica in cima a 24 settembre 2026.
## 20/09/2026

- Prima stesura da fonti ufficiali: Guidelines for Businesses v7.2 (giugno 2026), Terms of Use and Sale for Businesses v9.0 (23/06/2026), Action we take (marzo 2026), Legal Brand Guidelines (feb 2023), pagine piani/prezzi USD ed EUR, Invitation API (developers.trustpilot.com), pagine feature inviti e analytics, corporate.trustpilot.com/trust, blog Releases and updates (Shopify 29/06 e 10/07/2026, HubSpot 10/08/2026, Product Review Pages 13/08/2026, Product updates aprile 2026), Changes to reported reviews; Google: Valutazioni negozio (2375474), review snippet structured data, Search Central blog 09/2019; AGCM comunicato PS12962 (provv. 31878, 4 milioni di euro).
- Non verificato: tutte le pagine di help.trustpilot.com (Salesforce, solo JavaScript: TrustScore explained, AFS, review labels, flag reasons, store ratings FAQ, rich snippets prodotto, analytics per piano, integrazioni WooCommerce/PrestaShop/Shopify) sono state usate solo dagli estratti dei motori di ricerca; web.archive.org non raggiungibile. Non confermati: ritardo di default dell'AFS, comportamento oltre la quota inviti, soglie delle etichette verbali del TrustScore, "mezzo peso a 6 mesi" (solo mirror di terzi), prezzo degli add-on (recensioni di prodotto, API), data di spegnimento dell'app Shopify legacy, diff v7.1→v7.2 delle Guidelines, posizione del Garante sugli inviti a recensire, dichiarazione di conformità Trustpilot post-AGCM, discrepanza 12 mesi (FAQ Trustpilot) vs 24 mesi (Google) per le Valutazioni negozio.

## 21/09/2026

- Legal Brand Guidelines: sostituita la v2.0 (feb 2023) con la v3.0 (settembre 2026, https://corporate.trustpilot.com/legal/for-businesses/legal-brand-guidelines/sept-2026); link feb-2023 mantenuto nelle Fonti come "superata"; data di verifica in cima portata al 21/09/2026.
- Sez. 1: sul Free si può citare Trustpilot solo in testo semplice con link al profilo (più Review Collector Widget); vietati loghi, stelle, TrustScore, Star Label, Category Ranking e qualsiasi widget.
- Sez. 8: vietato sostituire un widget con un'immagine statica, vietati widget/plugin/estensioni non autorizzati, vietati widget Product Score in home page, landing page o accanto a prodotti non correlati.
- Sez. 12: numero totale di recensioni sempre accanto a TrustScore/stelle/Star Label; timbro "Trustpilot rating as of [Mese/Anno]" almeno 8 pt su materiale che non si aggiorna da solo; refresh almeno ogni 30 giorni ed entro 5 giorni lavorativi se il TrustScore scende di oltre 0,2; nome del recensore solo con permesso esplicito e documentato, altrimenti anonimizzazione completa; claim di ranking e confronti verificabili su Trustpilot al momento della pubblicazione; divieto di passare Brand Asset o contenuti a terzi; enforcement fino a restrizioni, nota sul profilo, fine abbonamento e azione legale.
- Sez. 12: rimossa la regola v2.0 sull'approvazione preventiva del CSM per TV, radio, audio digitale e affissioni: la v3.0 non la contiene più e dichiara che Trustpilot non approva né pre-autorizza singole campagne entro piano e linee guida.
- Sez. 13: aggiunta la voce Settembre 2026 (v3.0).
- Sez. 14: punto 9 esteso (plugin non autorizzati, Product Score in home/landing) e aggiunto punto 12 (creatività e materiali in giro).
- Sez. 16: quattro divieti aggiornati o aggiunti (Free solo testo, screenshot al posto del widget, punteggio senza numero recensioni/timbro/refresh, nome recensore senza permesso e asset a terzi).
- Non verificato: giorno esatto di pubblicazione della v3.0 (la pagina dice solo September 2026).
