# Changelog google-cloud

## 13/11/2026
- 🟡 Sez. 5: prezzi del Data Transfer Service riletti (connettori Alphabet gratuiti, terzi a slot-ora, anteprime gratuite, Google Play 25 $). Data in cima al 13/11/2026.

## 30/10/2026
- 🟡 Sez. 0 e 7: rimando aggiornato alla skill `gtm` (fino al 30/10/2026 `gtm-server-side`).
## 27/10/2026
- 🔴 Prima stesura su richiesta di Cristiano in chat («vorrei aggiungere la skill di google cloud»), 13 sezioni: progetti e organizzazione (Gmail consumer vs Cloud Identity), fatturazione (tipi di account, profilo pagamenti non modificabile, IVA Italia con Google Cloud Italy S.r.l. e e-fattura, ruoli, budget che non fermano la spesa, export su BigQuery), prova gratuita e Free Tier con i numeri, ruoli IAM minimi, account di servizio e chiavi API, BigQuery per GA4 e Search Console (limite di 1 milione di eventi al giorno, posizione del dataset, prezzi letti dal sorgente, controllo dei costi), Cloud Run per il server GTM (2 istanze, circa 45 $ al mese per server, prezzi), OAuth (100 utenti di test, scadenza a 7 giorni, verifica), Google Ads API senza developer token dal 09/09/2026 (Test, Explorer, Basic, Standard), quote Apps Script consumer vs Workspace, quote e supporto, igiene di un progetto ereditato, meccanica del pannello da verificare, cosa non fare mai. Fonti ufficiali lette il 27/10/2026; marcati [DA VERIFICARE] i punti non letti.
