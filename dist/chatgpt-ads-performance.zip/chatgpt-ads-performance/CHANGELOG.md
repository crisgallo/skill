# Changelog chatgpt-ads-performance

## 18/11/2026
- 🟡 Sez. 11: endpoint di stato revisione dei prodotti nei feed (is_approved, mappa review_status, header OpenAI-Ad-Account, uno SKU con più ID indicizzati), pagine product-feeds e hotel-feeds rilette il 18/11/2026.

## 17/11/2026
- 🔴 Sez. 3, 4, 7 e 8: 4 saperi verificati in pratica sul Blog (via Mother #28): indicatore dell'offerta CPC e pavimento a 1,95 €, una sola immagine per inserzione, utm_term={ad_id} in GA4 e colonna ID annuncio, «Pubblica» che lascia tutto spento.

## 13/11/2026
- 🔴 Sez. 6: le campagne da product feed si targetizzano anche per regioni e mercati dentro il paese dal 12/11/2026 (mail OpenAI del 12/11), località italiane [DA VERIFICARE]. 🔴 Sez. 11: filtri dei product set con più condizioni sullo stesso campo in Ads Manager; i docs API dicono ancora il contrario. Data in cima al 13/11/2026.

## 11/11/2026 (sera)
- 🔴 Sez. 8: sessione di test del Pixel in Ads Manager (Conversions > Data Source > Test; etichetta Test nell'Event Stream per 30 minuti, stessa origine, campionamento, gli eventi di test contano), dalla nuova sezione dei docs ufficiali comparsa fra il 04 e l'11/11/2026.

## 11/11/2026
- 🔴 Sez. 9: la documentazione del Measurement Pixel (11/11) dice che le view-through hanno finestra fissa di un giorno, sono una metrica separata a livello di campagna e non entrano in Conversions, al contrario della nota del 16/09; vale la documentazione, pannello [DA VERIFICARE]. Aggiunti consenso del Pixel e sorgenti CSP. Data in cima all'11/11/2026.

## 06/11/2026
- 🔴 Sez. 4: dal 09/11/2026 Target CPA (conversioni) e Target CPC (clic) al posto di Max Bid e Max CPC sulle campagne nuove; i due vecchi modelli cessano il 01/01/2027; «Maximize results» diventa «intelligent bidding»; controlli su Pixel/CAPI ed EQS prima del passaggio (mail OpenAI del 05/11).
## 04/11/2026
- 🟡 Sez. 2: mail OpenAI Ads del 02/11 (webinar Holiday Playbook del 04/11): credito per gli account Ads Manager aperti entro il 31/12/2026, importo [DA VERIFICARE]. `llms-full.txt` del 04/11: tolta la riga sul campo `<custom_field>` degli eventi `data.type = custom`, nessun altro cambiamento.
## 31/10/2026
- 🔴 Sez. 0, 2, 7 e 11: newsletter OpenAI del 30/10/2026: inserzioni con più immagini in open beta per tutti (Ad format > «Multiple images»), 89 paesi dal 21/10 (Italia già inclusa), miglioramenti creativi self-serve (riscrittura di titoli e descrizioni, traduzione, pagine più pertinenti; default e interruttore [DA VERIFICARE], articolo 403), scheda standard più larga su desktop, Shopify in tutti i paesi.
## 30/10/2026
- 🟡 Sez. 0 e 11: `llms-full.txt` del 30/10/2026: beta Hotel con campagne via API (solo USA, CPC manuale, un annuncio modello per gruppo), endpoint generico `POST /v1/feeds/{feed_id}/items/query` per feed di prodotto e Hotel (articoli idonei senza approvazione, limit 1-500), `start_time` omesso non significa più partenza immediata. Nessuna regola operativa per i clienti italiani cambia.

## 27/10/2026
- 🟡 Sez. 0, 7 e 11: changelog OpenAI del 26/10/2026: inserzioni con 4-6 immagini quadrate (`creative.file_ids`) per gli account abilitati, stesso titolo, testo e destinazione, campagne Reach/Clicks/Conversions con offerta fissa, regole di aggiornamento; nessun cambio per gli account non abilitati.

## 26/10/2026
- 🔴 Sez. 7: regola di Cristiano del 25/10/2026 (`feedback_piattaforme_e_campagne.md`, via manutenzione #17): ogni inserzione nasce con parametri URL dello standard del progetto, destinazione sulla pagina giusta, invito all'azione e clic di prova dopo la pubblicazione; brief senza i quattro punti rifiutati dal controllo automatico.

## 25/10/2026
- 🟡 Sez. 0 e 11: `llms-full.txt` del 25/10/2026: nuovo setting di feed `is_full_refresh` (PATCH /v1/feeds/{id}/settings): con l'opzione attiva ogni caricamento completo via SFTP sostituisce il catalogo e i prodotti assenti vengono cancellati entro un giorno; non tocca la Delta API; rimettere false non ripristina. Opt-in, default invariato.

## 20/10/2026
- 🟡 Sez. 6: `llms-full.txt` del 20/10/2026: nuovo valore di piattaforma `unknown` (client mancante o non riconosciuto, app Windows e macOS), `web` include i client web non classificati.
## 17/10/2026
- 🟡 Sez. 0 e 8: newsletter OpenAI del 16/10/2026: pagina Conversions di Ads Manager ridisegnata con avvisi collegati a Diagnostics, mail settimanale di rendimento, Bug report e Product feedback dal menu account, test di formati visivi più larghi e del formato a più immagini (solo USA), nuovi partner di misurazione (Northbeam, DV Rockerbox, INCRMNTAL; Kochava, Tenjin, Airbridge; pagine 403, [DA VERIFICARE]).
## 16/10/2026
- 🟡 Sez. 8: pagina Conversions API riletta il 16/10/2026: le liste dei campi plurali dell'advanced matching accettano al massimo tre valori (anche unendo singolare e plurale), oltre HTTP 400 senza troncamento (prima: usati i primi tre, resto ignorato); `android_advertising_id` (GAID) solo via CAPI, IDFA non supportato, ID tutti zero ignorati; changelog del 19/08/2026 con i campi plurali e il GAID in CAPI e i nuovi campi del pixel.
## 14/10/2026
- 🟡 Sez. 8: documentazione OpenAI del 14/10/2026: via CAPI si mandano tutti gli eventi di conversione, non solo quelli con `oppref`, per includere le view-through nelle metriche.

## 10/10/2026
- 🔴 Sez. 8: la documentazione OpenAI (supported-events, cambiata il 09-10/10/2026) definisce `contents[].amount` come prezzo per unità con `quantity` a parte e l'`amount` di evento come valore dell'intero evento, con l'esempio 2 x 79900 = 159800; prima la riga era ambigua. Da verificare come le integrazioni attive riempiono `contents`.
## 06/10/2026
- 🔴 Sez. 0 e 8: documentazione developers.openai.com del 06/10/2026 sui parametri di tracciamento dei product feed (precedenza Feed < Account < Campagna < Gruppo < Annuncio, tracking settings di account) e migrazione obbligatoria dall'ordine Legacy entro il 05/11/2026 con «Switch now» da amministratore. Sez. 0: annuncio OpenAI del 05/10/2026 del formato visivo accanto alle immagini generate (test solo USA, utenti Free e Go, dal mese in corso), nuovi partner di misurazione, piloti di brand suitability DoubleVerify e IAS, geo-test; non riguarda l'Italia (pagina ufficiale 403, letta via TechCrunch).
## 02/10/2026
- 🟡 Sez. 0: feed alberghieri in beta chiusa (02/10/2026), non pertinenti. Pagine API rilette: nessun altro cambio. Data di verifica al 02/10.
## 01/10/2026
- 🔴 Sez. 0, 2, 7 e 9 (newsletter OpenAI del 30/09/2026 segnalata da Cristiano): tre nomi separati con le regole di pausa (brand ferma la consegna, legale riavvia la revisione); campagne da product feed in blocco da foglio e stato di revisione dei prodotti; conversioni oltre l'obiettivo nell'API con include attributed_events; mercati asiatici già in sez. 1.
- 🔴 Sez. 0, 9, 11: changelog API del 30/09/2026: finestre di attribuzione e base temporale su tutti gli endpoint Insights con default 30 giorni clic, 1 giorno view, ad-event time (i totali includono le view-through); nuovo endpoint Audit Logs (solo chiave API). Data di verifica al 01/10.
## 26/09/2026
- 🟡 Sez. 2 e sez. 0: dal 24/09/2026 ChatGPT Ads è in sette mercati asiatici in più e «più di 60 paesi» (annuncio OpenAI non leggibile, 403; conteggio da Marketing-Interactive, terzi, `[DA VERIFICARE]`). Sez. 9: limiti dell'API Insights (2.000 righe, 413, 365 giorni, granularità, valori platform) dalla pagina developers.openai.com cambiata il 26/09/2026. Nessuna regola operativa per l'Italia cambia.
## 23/09/2026
- Sez. 6: piattaforme confermate dalla pagina platform-targeting (cinque più `web` legacy; omesso = nessuna restrizione); chiusa la discrepanza segnalata il 22/09.
- Sez. 4: oCPC con un solo evento standard attivo, niente custom come obiettivo, obiettivo ed evento immutabili dopo la creazione (conversion-optimized-campaigns).
- Sez. 11: limiti della Bulk API (1.000 operazioni per job, 16 MiB, 512 KiB, tetti 5.000; limited preview per account).

## 22/09/2026
- Sez. 2.1 e 6: la pagina campaign-targeting (letta il 22/09/2026) documenta il targeting sub-nazionale via location ID e le esclusioni di regione; product feed solo a livello paese; per l'Italia resta da verificare sul pannello. Segnalata la discrepanza sulle piattaforme (tre sulla pagina, cinque nel changelog API). Data in cima riscritta.

## 20/09/2026

- §0: aggiornata la data di verifica al 20/09/2026; aggiunte le regole 5 (leggere il changelog di developers.openai.com/ads a ogni verifica) e 6 (help.openai.com e openai.com rispondono 403 al fetch automatico); aggiunto il blocco datato «Cosa è cambiato dal 12/09/2026». Fonte: audit del 20/09/2026, https://developers.openai.com/ads
- §1: corretto il piano che vede le inserzioni da «Standard» a «Go»; aggiunti Enterprise ed Edu tra gli esclusi; aggiunto che gli annunci non compaiono in Temporary Chat e Atlas e che l'utente Free può scegliere «Ads-Free». Fonte: https://help.openai.com/en/articles/20001047-ads-in-chatgpt · https://help.openai.com/en/articles/20001207-ads-in-chatgpt-the-basics
- §1: aggiunta la personalizzazione con segnali dall'esperienza ChatGPT (~17/09/2026), con nota che non è attiva in EEA/Svizzera. Fonte: https://help.openai.com/en/articles/20001207-ads-in-chatgpt-the-basics
- §1: aggiunti i mercati dove le inserzioni vengono servite, con l'Italia dal 24/08/2026. Fonte: https://openai.com/index/chatgpt-ads-expands-across-europe/
- §1: aggiunti i Sponsored Agents (16/09/2026, alpha USA, non promettibili). Fonte: https://help.openai.com/en/articles/20001524-sponsored-agents-in-chatgpt-ads
- §2: aggiornato il conteggio dei paesi self-serve da 54 a 56. Fonte: https://help.openai.com/en/articles/20001245-ads-manager-availability
- §2: corretta la regola «un account per entità giuridica»: più account per azienda ammessi, tetto a 10 ad account per utente; precisato che l'agenzia può essere invitata dopo che il cliente ha creato l'account. Fonte: https://help.openai.com/en/articles/20001213-ads-manager-beta-account-setup · https://help.openai.com/en/articles/20001217-troubleshooting-common-issues
- §2: sostituita «verifica Persona» con «flusso di verifica di identità o aziendale» e marcato il nome del fornitore come non trovato in nessuna fonte; riformulata la regola su nome e logo con il testo dell'help (campagne non servite finché setup e revisione non sono completi). Fonte: https://help.openai.com/en/articles/20001213-ads-manager-beta-account-setup
- §2: aggiunto il plugin Ads Manager dentro ChatGPT (03/09 e 16/09/2026). Fonte: https://openai.com/index/reimagining-advertising-with-ai/
- §2: riscritta la fatturazione: soglia iniziale bassa che sale con lo storico, saldo residuo addebitato a fine mese anche sotto soglia, blocco carta temporaneo con importo mostrato nel setup e visibile fino a 8 giorni; rimosse le cifre «50 o 100 $» e marcate come non trovate in nessuna fonte. Fonte: https://help.openai.com/en/articles/20001216-billing-payment (aggiornata 19-20/09/2026)
- §2: aggiunti i limiti di spesa account solo per fatturazione postpagata (09/09/2026), la pausa efficace entro 24 ore, il credito di benvenuto 500 $ su 500 $ spesi, le integrazioni HubSpot (16/09/2026) e Shopify (USA 16/09, internazionale 23/09/2026). Fonte: https://developers.openai.com/ads · https://help.openai.com/en/articles/20001216-billing-payment · https://ads.openai.com/ · https://help.openai.com/en/articles/20001522-set-up-chatgpt-ads-in-hubspot · https://openai.com/index/reimagining-advertising-with-ai/
- §2.1 (nuova sottosezione Italia/EEA): pubblici personalizzati non supportati per campagne EEA/Svizzera; account self-serve nuovi limitati al paese di casa fino a verifica e spesa minima; targeting sub-nazionale per l'Italia non verificato (geotargets.csv non scaricabile); personalizzazione non attiva in EEA; designazione DSA riportata da ppc.land e non verificata. Fonte: https://help.openai.com/en/articles/20001210-create-campaigns-for-chatgpt-ads · https://developers.openai.com/ads/custom-audiences · https://help.openai.com/en/articles/20001217-troubleshooting-common-issues
- §3: aggiornata la tabella con oCPM, budget giornaliero o totale, cinque piattaforme, exclusion_hints, bid multiplier e parametri URL dinamici; aggiunto che il bulk CSV accetta solo «Views or Clicks» e non crea campagne da feed. Fonte: https://help.openai.com/en/articles/20001218-bulk-upload-campaign-schema-checklist
- §4: aggiunto l'obiettivo oCPM (generally available dal 16/09/2026). Fonte: https://help.openai.com/en/articles/20001412-conversion-optimized-campaigns · https://openai.com/index/reimagining-advertising-with-ai/
- §4: corretto il Bid Cap sulle campagne a conversione: è un'offerta CPA (max_bid_micros = CPA bid), non un CPC; aggiunto che per oCPC/oCPM non esiste offerta consigliata e che 3-5 $ vale solo per CPC. Fonte: https://developers.openai.com/ads/conversion-optimized-campaigns · https://help.openai.com/en/articles/20001412-conversion-optimized-campaigns
- §4: precisato che Maximize results è il default sui gruppi nuovi e che l'offerta fissa («Manual: Max bid») va scelta esplicitamente; aggiunta la regola budget giornaliero ≥ offerta più alta con offerta fissa; aggiunti bid strength e avviso «Low bid». Fonte: https://help.openai.com/en/articles/20001425-maximize-results-bid-strategy · https://help.openai.com/en/articles/20001413-daily-budgets · https://help.openai.com/en/articles/20001217-troubleshooting-common-issues
- §5: sostituito «minimo in euro non documentato» con la tabella Minimum Campaign Spend (EUR 15, GBP 15, CHF 20, USD 25, PLN 65, SEK 175). Fonte: https://help.openai.com/en/articles/20001210-create-campaigns-for-chatgpt-ads
- §5: aggiunto il budget totale di campagna, la non reversibilità del passaggio a giornaliero e la precisazione che i periodi 365/60 giorni valgono solo per il budget totale. Fonte: https://help.openai.com/en/articles/20001515-budget-pacing
- §6: corretta la geografia (sub-nazionale «where available», non più solo USA; product feed solo paese); aggiornate le piattaforme a cinque con i valori API (10/09/2026); aggiunto l'articolo dedicato ai context hints e il campo exclusion_hints del Bulk API. Fonte: https://help.openai.com/en/articles/20001210-create-campaigns-for-chatgpt-ads · https://developers.openai.com/ads · https://help.openai.com/en/articles/20001521-write-context-hints-for-chatgpt-ads · https://developers.openai.com/ads/bulk-api
- §6: pubblici personalizzati: aggiunto il divieto per campagne EEA/CH, le novità del 25/08/2026 (add/remove/replace, identificatori misti, oltre 5M, bid multiplier 0,1x-10x, consigliati ≥100.000), il flusso file (eliminati entro 24 h, processing 20-30 min, «Ready — Exclusion only»). Fonte: https://developers.openai.com/ads/custom-audiences · https://help.openai.com/en/articles/20001346-set-up-custom-audiences-for-your-campaign
- §6: riformulata la lingua: nessun targeting, ma esiste la traduzione automatica del testo. Fonte: https://openai.com/index/reimagining-advertising-with-ai/
- §7: aggiunte le creatività suggerite (drafts dai metadata e copy/immagini AI dal 16/09/2026), l'opt-in «AI-powered text customization» con traduzione, le campagne da product feed (item scaduti dopo 2 settimane, OAI-SearchBot per le immagini). Fonte: https://help.openai.com/en/articles/20001212-create-ads-for-chatgpt-ads · https://openai.com/index/reimagining-advertising-with-ai/ · https://help.openai.com/en/articles/20001268-create-campaigns-from-product-feeds
- §8: corretto plan_id da richiesto a opzionale su subscription_created e trial_started. Fonte: https://developers.openai.com/ads/supported-events
- §8: aggiunto il cookie __obref passato alla CAPI come events[].user.obref (16/07/2026). Fonte: https://developers.openai.com/ads/conversions-api
- §8: riscritta la qualità degli eventi con il punteggio per data source e i nove avvisi documentati; scala 1-10 marcata come riportata solo da ppc.land. Fonte: https://help.openai.com/en/articles/20001513-understand-and-improve-event-quality
- §8: aggiunte le integrazioni Measurement Partner e MMP. Fonte: https://help.openai.com/en/articles/20001416-set-up-measurement-partner-integrations · https://help.openai.com/en/articles/20001372-set-up-mobile-measurement-partner-integrations
- §9: aggiunto il segmento Platform (senza conversioni via API) e le nuove colonne (eventi singoli, Order Created Sales/ROAS, Click-through e View-through separate, Conversions by conv. time). Fonte: https://help.openai.com/en/articles/20001214-measure-results · https://developers.openai.com/ads/api-reference/insights
- §9: riscritta l'attribuzione: post clic 7/14/30 giorni, view-through 0 o 1 giorno, colonna Conversions che include le view-through con 1 Day, istruzione per il confronto con GA4. Fonte: https://help.openai.com/en/articles/20001214-measure-results · https://openai.com/index/reimagining-advertising-with-ai/
- §9: aggiunti i parametri URL dinamici {campaign_id}, {ad_group_id}, {ad_id}, {ad_account_id}. Fonte: https://help.openai.com/en/articles/20001214-measure-results
- §10: aggiunte le categorie vietate di v1.4 (annunci di lavoro e immobiliari singoli, scams, sensitive topics, wellness claims) e la clausola v1.6 di rifiuto per conflitto con interessi commerciali di OpenAI. Fonte: https://openai.com/policies/ad-policies/
- §10: sostituito l'elenco puntuale dei contesti sensibili con il testo attuale della policy («sensitive user contexts», «brand unsafe contexts», v1.1 su consiglio medico/legale/finanziario) e marcato l'elenco precedente come non trovato in nessuna fonte. Fonte: https://openai.com/policies/ad-policies/ · https://help.openai.com/en/articles/20001047-ads-in-chatgpt
- §11: aggiunte le regole operative API: rate limit, micros e max_cpm_bid_micros, valori di bidding_type, stato paused alla creazione, valori piattaforma, exclusion_hints, obref, segmento platform in Insights, changelog da leggere; aggiunti i link a location-targeting, platform-targeting, custom-audiences, bulk-api, insights. Fonte: https://developers.openai.com/ads (Overview e changelog via llms-full.txt)
- §12: rimossi «minimo in euro» e «dove vengono servite» dalle assenze; aggiunti pubblici per EEA, offerta consigliata per conversione, Sponsored Agents fuori USA; aggiornata la lettura per gruppo con i parametri dinamici.
- §13: aggiornato il test: vincolo paese di casa, minimo 15 €/giorno da confermare, scelta esplicita di «Manual: Max bid», niente liste sull'Italia, view-through a 0 Day, parametri dinamici in GA4, integrazioni Shopify/HubSpot.
- Fonti: riscritta con la data 20/09/2026, il metodo di lettura (403 su help.openai.com/openai.com/ads.openai.com, letti via reader proxy e Wayback, prossima verifica da browser), i nuovi URL (utenti, context hints, product feeds, HubSpot, Sponsored Agents, MMP, measurement partners, changelog, llms-full, location/platform targeting, custom audiences API, bulk API, insights, Europa, Reimagining advertising, ppc.land); aggiornata la nota finale con le cose da riverificare sul pannello.
- Non verificabile al 20/09/2026: importo del blocco di preautorizzazione (le cifre 50/100 $ non stanno in nessuna fonte), nome del fornitore di verifica «Persona», elenco puntuale dei contesti sensibili esclusi, esistenza di località sub-nazionali per l'Italia (geotargets.csv dietro challenge Cloudflare), scadenza a 90 giorni del credito di benvenuto (fonti terze), scala 1-10 del punteggio qualità eventi (solo ppc.land), designazione DSA di ChatGPT (solo ppc.land), esposizione di exclusion_hints nel pannello, spesa minima nel paese di casa per sbloccare altri paesi (non quantificata da OpenAI).
